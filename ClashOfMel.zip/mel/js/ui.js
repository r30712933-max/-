// ui.js — интерфейс: окна, магазин, карточки зданий, армия, коллекция, лаборатория, результаты
const $=s=>document.querySelector(s);
const fmt=n=>Math.floor(n).toLocaleString('ru-RU');
function toast(m){const d=document.createElement('div');d.textContent=m;$('#toast').appendChild(d);setTimeout(()=>d.remove(),2900)}
const iconCache={};const icon=t=>iconCache[t]||(iconCache[t]=getArt(t,1).c.toDataURL());
const uimg=i=>SPR['u'+i];
let curWin=null,winTimer=0;
function openWin(title,render,onclose){curWin={title,render,onclose};$('#wtt').textContent=title;$('#modal').classList.add('on');renderWin();clearInterval(winTimer);winTimer=setInterval(()=>{if(curWin&&curWin.live)curWin.live()},500)}
function renderWin(){if(!curWin)return;const wb=$('#wb'),sc=wb.scrollTop;wb.innerHTML=curWin.render();wb.scrollTop=sc}
function closeWin(){const w=curWin;curWin=null;clearInterval(winTimer);$('#modal').classList.remove('on');if(w&&w.onclose)w.onclose()}
$('#wx').onclick=()=>{snd('click');closeWin()};
$('#modal').addEventListener('pointerdown',e=>{if(e.target.id=='modal')closeWin()});
$('#wb').addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el||el.disabled)return;snd('click');const f=UIA[el.dataset.a];if(f)f(el.dataset.v)});
const lockTxt=r=>r?`<div class="tg">${r}</div>`:'';
// ---------- магазин ----------
const CATS=[['main','Главное'],['res','Ресурсы'],['army','Армия'],['def','Оборона'],['deco','Декор'],['store','Склад']];
let shopTab='main';
function shopHtml(){let h='<div class="tabs">'+CATS.map(([k,n])=>`<button data-a="shopTab" data-v="${k}" class="${k==shopTab?'on':''}">${n}</button>`).join('')+'</div><div class="grid">';
 if(shopTab=='store'){const st=S.bld.filter(b=>b.stored);h+=st.length?st.map(b=>`<div class="card" data-a="placeStored" data-v="${b.id}"><img src="${icon(b.t)}"><b>${BD[b.t].n}</b><div class="pr">ур. ${b.l}</div></div>`).join(''):'<p>Склад пуст. Здания можно убрать с поля через карточку здания.</p>'}
 else{const th=thLevel();for(const t in BD){if(BD[t].cat!=shopTab)continue;const u=unlockTH(t),lock=u>th,mx=maxCount(t,th),c=countOf(t);
  h+=`<div class="card ${lock?'lock':''}" data-a="shopItem" data-v="${t}">${lock?lockTxt('Рез. ур.'+u):''}<img src="${icon(t)}"><b>${BD[t].n}</b><div class="pr">🪙 ${fmt(BD[t].cost)}</div>${lock?'':`<span class="cn">${c}/${mx}</span>`}</div>`}}
 return h+'</div>'}
function shopItemHtml(t){const b=BD[t],r=reasonCantBuild(t),th=thLevel();let st='';
 if(DEF_TYPES.includes(t)||TRAPS.includes(t)){const d=dStat(t,1);st=`Урон ${Math.round(d.dmg)}${d.rate?' · выстрел раз в '+d.rate+' с':''} · дальность ${d.rng}${d.spl?' · радиус '+d.spl:''}${d.air?' · бьёт воздух':''}`}
 else if(prod(t,1)){const p=prod(t,1);st='Добыча: '+Object.keys(p).map(k=>(p[k]).toFixed(1)+'/с '+(k=='gold'?'🪙':'🍼')).join(' ')}
 else if(t=='camp')st='Места в армии: +'+campCap(1);else if(t.endsWith('store'))st='Вместимость: +'+fmt(storeCap(1));else st='Прочность '+bHp(t,1);
 return `<div class="det"><img src="${icon(t)}"><div><p>${b.d}</p><p><b>${st}</b></p><p>Размер ${b.w}×${b.w} · Построено ${countOf(t)}/${maxCount(t,th)} · Время ${b.bt>1?b.bt+' с':'мгновенно'}</p></div></div>
 <div class="row" style="margin-top:10px"><button data-a="shopBack">← Назад</button><button class="go" data-a="shopBuild" data-v="${t}" ${r?'disabled':''}>${r||'Построить · 🪙 '+fmt(b.cost)}</button></div>`}
// ---------- карточка здания ----------
let selB=null;
function selHtml(b){const d=BD[b.t],th=thLevel();let info='';
 if(DEF_TYPES.includes(b.t)||TRAPS.includes(b.t)){const s=dStat(b.t,b.l);info=`Урон ${Math.round(s.dmg)} · дальность ${s.rng}${s.rate?' · темп '+(1/s.rate).toFixed(1)+'/с':''}`}
 else if(prod(b.t,b.l)){const p=prod(b.t,b.l,chekBonus());info='Добыча: '+Object.keys(p).map(k=>p[k].toFixed(1)+'/с '+(k=='gold'?'🪙':'🍼')).join(' ')+` · Накоплено: ${Object.keys(p).map(k=>fmt(b.acc[k]||0)).join('/')}`}
 else if(b.t=='camp')info='Места в армии: +'+campCap(b.l);else if(b.t=='gold_store'||b.t=='chek_store')info='Вместимость: +'+fmt(storeCap(b.l));
 else if(b.t=='barracks')info=`Скорость тренировки ×${(1+.2*(b.l-1)).toFixed(1)} · очередь ${queueCap()}`;
 else if(b.t=='residence')info=`${thName[b.l]} · хранит ${fmt(resGold(b.l))} 🪙 / ${fmt(resChek(b.l))} 🍼`;
 else if(b.t=='chek_house')info=`+${b.l*10}% к добыче чекушек`;else if(b.t=='sub_center')info=`+${b.l*15}% кубков, +${b.l*6}% добычи с нападений`;
 else if(b.t=='lab')info='Улучшает бойцов до ур. '+labMax(b.l);else info=`Прочность ${bHp(b.t,b.l)}`;
 let up='';if(busy(b))up=`<button disabled>${b.cons?'Строится':'Улучшается'}… ${fmtT((b.up-nowMs())/1000)}</button>`;
 else{const r=reasonCantUp(b),n=b.l+1;const can=r!='Максимальный уровень'&&(!r||!r.startsWith('Нужна')||true);up=(r=='Максимальный уровень'||BD[b.t].ml[4]<=1)?'<button disabled>Максимальный ур.</button>':`<button class="go" data-a="upgrade" ${r?'disabled':''}>${r||('⬆ Ур. '+n+' · 🪙 '+fmt(upCost(b.t,n))+' · '+fmtT(upTime(b.t,n)))}</button>`}
 let sp='';if(b.t=='barracks')sp='<button data-a="winArmy">⚔ Тренировка</button>';if(b.t=='lab')sp='<button data-a="winLab">🧪 Улучшить бойцов</button>';if(b.t=='hype_arena'&&!busy(b))sp='<button class="no" data-a="arena">🔥 Испытание хайпа</button>';
 if(b.t=='residence'){const nx=[];for(const t in BD){const u=unlockTH(t);if(u==b.l+1&&u>1)nx.push(BD[t].n)}sp=nx.length&&b.l<5?`<p style="flex:1 0 100%">Откроет: ${nx.join(', ')}</p>`:''}
 return `<h3>${d.n} · ур. ${b.l}</h3><p>${info}</p><div class="row">${up}${sp}${b.t=='wall'||isDeco(b.t)?'':''}<button data-a="moveB">✥ Переместить</button>${b.t=='residence'?'':'<button data-a="storeB">📦 На склад</button>'}<button data-a="selClose">Закрыть</button></div>`}
function showSel(b){selB=b;if(!b){$('#sel').classList.remove('on');return}$('#sel').innerHTML=selHtml(b);$('#sel').classList.add('on')}
// ---------- армия ----------
let armyTab='train';
function qHtml(){const q=S.queue.length?S.queue.map((q,i)=>`<div class="card" data-a="cancelQ" data-v="${i}"><img src="${uimg(q.u)}"><div class="bar" style="margin:2px"><i style="width:${Math.min(100,q.p/trainTime(q.u)*100)}%"></i></div>✕</div>`).join(''):'<p style="margin:8px">Очередь пуста. Нажимай на бойцов ниже.</p>';
 return`<div class="q">${q}</div>`}
function capHtml(){const used=armyUsed(),q=queueUsed(),cap=armyCap();return `<div>Армия ${used}${q?' +'+q+' в очереди':''} / ${cap} мест · очередь ${S.queue.length}/${queueCap()}</div><div class="bar"><i style="width:${Math.min(100,(used+q)/cap*100)}%"></i></div>`}
function armyHtml(){let h='<div class="tabs"><button data-a="armyTab" data-v="train" class="'+(armyTab=='train'?'on':'')+'">Тренировка</button><button data-a="armyTab" data-v="coll" class="'+(armyTab=='coll'?'on':'')+'">Коллекция</button></div>';
 if(armyTab=='train'){h+='<div id="capb">'+capHtml()+'</div><div id="qb">'+qHtml()+'</div><div class="grid">';
  for(let i=0;i<UC.length;i++){const lock=unlockLvl(i)>thLevel();if(lock)continue;h+=`<div class="card" data-a="train" data-v="${i}"><span class="cn">×${S.army[i]||0}</span><img src="${uimg(i)}"><b>${UC[i][0]}</b><div class="pr">🍼 ${trainCost(i)} · ${unitSpace(i)}м</div></div>`}
  h+='</div>'}
 else{h+=`<p style="font-size:12px;margin:2px 0 8px">Открыто ${UC.filter((c,i)=>unlockLvl(i)<=thLevel()).length} из ${UC.length}. Новые бойцы открываются с ростом Резиденции.</p><div class="grid">`;
  for(let i=0;i<UC.length;i++){const lock=unlockLvl(i)>thLevel();h+=`<div class="card ${lock?'lock':''}" data-a="unitInfo" data-v="${i}">${lock?lockTxt('Рез. ур.'+unlockLvl(i)):''}<span class="cn">ур.${unitLvl(i)}</span><img src="${uimg(i)}"><b>${UC[i][0]}</b><div style="opacity:.8">${ROLES[UR[i]]}</div></div>`}h+='</div>'}
 return h}
function unitInfoHtml(i){const s=uStat(i,unitLvl(i)),lock=unlockLvl(i)>thLevel(),dps=s.dmg/s.cd;const n=unitLvl(i)+1,r=reasonCantResearch(i);
 return `<div class="det"><img src="${uimg(i)}"><div><p><b>${s.n}</b> · ${ROLES[UR[i]]} · ур. ${unitLvl(i)}</p><p>${UD[UC[i][9]]||'Обычный боец без особых способностей'}</p></div></div>
 <table class="st"><tr><td>Здоровье</td><td>${s.hp}</td></tr><tr><td>Урон</td><td>${Math.round(s.dmg)} (${s.cd?Math.round(dps)+'/с':'—'})</td></tr><tr><td>Скорость</td><td>${s.sp.toFixed(1)} тайла/с</td></tr><tr><td>Дальность</td><td>${s.rng.toFixed(1)}</td></tr><tr><td>Цели</td><td>${s.fly?'воздух (летает)':s.hunt?'сначала оборона':'ближайшие здания'}</td></tr><tr><td>Место в армии</td><td>${unitSpace(i)}${s.cnt>1?' (выходит '+s.cnt+' шт.)':''}</td></tr><tr><td>Тренировка</td><td>🍼 ${trainCost(i)} · ${fmtT(trainTime(i))}</td></tr><tr><td>Открывается</td><td>Рез. ур. ${unlockLvl(i)}</td></tr></table>
 <div class="row" style="margin-top:8px"><button data-a="armyBack">← Назад</button>${lock?'':`<button class="go" data-a="research" data-v="${i}" ${r?'disabled':''}>${r||'🧪 Ур. '+n+' · 🍼 '+labCost(i,n)+' · '+fmtT(labTime(i,n))}</button>`}</div>`}
function labHtml(){const l=labB();if(!l)return '<p>Лаборатория мемов не построена (Магазин → Армия, нужна Резиденция ур. 2) или ещё строится.</p>';
 let h=`<p>Лаборатория ур. ${l.l}: бойцы до ур. ${labMax(l.l)}. ${S.lab?`<b>Идёт: ${UC[S.lab.u][0]} → ур. ${S.lab.l} (${fmtT((S.lab.end-nowMs())/1000)})</b>`:'Лаборатория свободна.'}</p><div class="grid">`;
 for(let i=0;i<UC.length;i++){if(unlockLvl(i)>thLevel())continue;h+=`<div class="card" data-a="unitInfo" data-v="${i}"><span class="cn">ур.${unitLvl(i)}</span><img src="${uimg(i)}"><b>${UC[i][0]}</b><div class="pr">${unitLvl(i)>=labMax(l.l)?'макс.':'🍼 '+labCost(i,unitLvl(i)+1)}</div></div>`}return h+'</div>'}
// ---------- инфо ----------
function infoHtml(){const th=thLevel(),done=ACH.filter(a=>S.ach[a.id]).length;
 return `<table class="st"><tr><td>Резиденция Мэла</td><td>${thName[th]} (ур. ${th})</td></tr><tr><td>Уровень игрока</td><td>${playerLevel()} (опыт ${S.xp})</td></tr><tr><td>Кубки</td><td>🏆 ${S.cups}</td></tr><tr><td>Нападений / побед</td><td>${S.stats.att} / ${S.stats.wins}</td></tr><tr><td>Всего звёзд</td><td>${S.stats.stars}</td></tr><tr><td>Награблено</td><td>${fmt(S.stats.looted)}</td></tr><tr><td>Зданий на базе</td><td>${S.bld.filter(b=>!b.stored).length}</td></tr><tr><td>Армия</td><td>${armyUsed()}/${armyCap()}</td></tr><tr><td>Строителей занято</td><td>${busyBuilders()}/${builders()}</td></tr></table>
 <div class="row" style="margin:10px 0"><button class="go" data-a="defTest">🛡 Проверить оборону (учебный набег)</button></div>
 <h3 style="margin:8px 0 4px">Достижения ${done}/${ACH.length}</h3>${ACH.map(a=>`<div class="ach ${S.ach[a.id]?'d':''}"><span><b>${a.n}</b> — ${a.d}</span><span>${S.ach[a.id]?'✓':'+'+a.r+'🪙'}</span></div>`).join('')}`}
function settingsHtml(){return `<p>Громкость</p><input type="range" min="0" max="100" value="${Math.round(VOL*100)}" style="width:100%" oninput="setVol(this.value/100);S.opts.vol=this.value/100">
 <div class="row" style="margin:10px 0"><button data-a="mute">${mute?'🔇 Звук выключен':'🔊 Звук включён'}</button><button data-a="saveNow">💾 Сохранить</button></div>
 <p style="font-size:12px;opacity:.8">Сохранение — автоматически (ключ ${SAVE_KEY}). Игра «КЛЭШ ОФ МЭЛ» v1.0. Чекушки — вымышленная игровая валюта.</p>
 <div class="row"><button class="no" data-a="reset">Сбросить прогресс</button></div>`}
// ---------- поиск базы ----------
let curBase=null;
function atkHtml(){const b=curBase;const hasArena=S.bld.find(x=>x.t=='hype_arena'&&active(x));
 return `<h3 style="margin:2px 0">${b.name}</h3><table class="st"><tr><td>Резиденция Мэла</td><td>ур. ${b.layout.find(e=>e[0]=='residence')[3]}</td></tr><tr><td>Золото</td><td>🪙 ${fmt(b.gold)}</td></tr><tr><td>Чекушки</td><td>🍼 ${fmt(b.chek)}</td></tr><tr><td>Сложность</td><td>${b.diff}</td></tr><tr><td>Награда кубками</td><td>🏆 до +${Math.round(b.cups*1.5)}</td></tr><tr><td>Твоя армия</td><td>${armyUsed()} мест</td></tr></table>
 <div class="row" style="margin-top:10px"><button data-a="scout">👁 Разведка</button><button class="no" data-a="attack" ${armyUsed()?'':'disabled'}>⚔ Напасть!</button></div>
 <div class="row" style="margin-top:6px"><button data-a="nextBase" ${S.gold<40?'disabled':''}>🔎 Следующий · 🪙 40</button>${hasArena?'<button data-a="arena">🔥 Арена хайпа</button>':''}</div>${armyUsed()?'':'<p>Сначала натренируй бойцов в Казармах (⚔ Армия).</p>'}`}
// ---------- результат ----------
function resultHtml(B,extra){const win=B.stars>0;return `<div class="res"><h2>${extra&&extra.title||(win?'ПОБЕДА!':'Поражение')}</h2><div class="stars">${[0,1,2].map(i=>`<span class="${i<B.stars?'on':''}" style="animation-delay:${i*.3}s">★</span>`).join('')}</div>
 <table class="st"><tr><td>Разрушено</td><td>${B.pct}% (${B.dead}/${B.tot} зданий)</td></tr>${extra&&extra.def?'':`<tr><td>Украдено золота</td><td>🪙 ${fmt(B.gold||0)}</td></tr><tr><td>Украдено чекушек</td><td>🍼 ${fmt(B.chek||0)}</td></tr><tr><td>Кубки</td><td>🏆 ${B.cups>0?'+':''}${B.cups||0}</td></tr><tr><td>Потери армии</td><td>${B.lost} бойц.</td></tr>`}${extra&&extra.rows||''}</table>
 <div class="row" style="margin-top:12px"><button class="go" data-a="home">Домой</button>${extra&&extra.def?'':'<button data-a="again">Ещё бой</button>'}</div></div>`}
