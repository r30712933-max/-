// ai.js — поведение бойцов (цели, движение с обходом, способности) и заранее подготовленные базы противников.
const solidAt=(B,x,y,u)=>{if(x<0||y<0||x>=GN||y>=GN)return true;const id=B.occ[(x|0)*GN+(y|0)];if(!id)return false;if(u&&u.fl=='h'&&B.bld[id-1].t=='wall')return false;return true};
function nearestB(B,u,pred){let best=null,bd=1e9;for(const b of B.bld){if(b.dead||!pred(b))continue;const d=distRect(b,u.x,u.y);if(d<bd){bd=d;best=b}}return best}
function pickTarget(B,u){u.tg=null;u.tk='';
 if(u.fb&&!u.fb.dead&&u.fbt>0){u.tg=u.fb;u.tk='b';return}
 if(u.fl=='l'){let best=null,bd=1e9;for(const o of B.units)if(o.s==u.s&&o!==u&&o.hp>0&&o.fl!='l'){const d=Math.hypot(o.x-u.x,o.y-u.y);if(d<bd){bd=d;best=o}}if(best){u.tg=best;u.tk='f'}return}
 let eu=null,ed=u.s==1?(u.home?6:99):2.6;for(const o of B.units)if(o.s!=u.s&&o.hp>0&&!o.hid&&(!o.fly||u.ranged||u.fly||u.s==0)){const d=Math.hypot(o.x-u.x,o.y-u.y);if(d<ed){ed=d;eu=o}}
 if(eu&&!(u.fl=='k')){u.tg=eu;u.tk='u';return}
 if(u.s==1)return;
 let b=null;if(u.hunt)b=nearestB(B,u,b=>DEF_TYPES.includes(b.t));if(!b)b=nearestB(B,u,b=>countsAsTarget(b.t));
 if(b){u.tg=b;u.tk='b'}}
function stepUnit(B,u,dt){u.t+=dt;if(u.flash>0)u.flash-=dt;
 if(u.slow>0)u.slow-=dt;if(u.wet>0)u.wet-=dt;if(u.haste>0)u.haste-=dt;if(u.st>0){u.st-=dt;return}
 if(u.fire>0){u.fire-=dt;u.hp-=6*dt;if(u.hp<=0){killUnit(B,u);return}}
 // пассивные способности
 const fl=u.fl;
 if(fl=='g'){u.gt+=dt;if(u.gt>10){const r=u.hp/u.mx,s=uStat(30,u.lv);u.i=30;u.fl='n';u.mx=s.hp;u.hp=Math.max(30,s.hp*r);u.dmg=s.dmg;u.sp=s.sp;u.sz=s.sz;u.cd=s.cd;u.rng=s.rng;burst(B,u.x,u.y,'#ffe9a8',12,2.5);fxRing(B,u.x,u.y,'#ffe9a8')}}
 if(fl=='n'){u.lt+=dt;if(u.lt>6&&B.units.length<90){u.lt=0;spawnUnit(B,28,u.x+.3,u.y+.3,u.s,u.lv)}}
 if(fl=='v'||fl=='a'||fl=='w'){u.ft+=dt;if(u.ft>.4){u.ft=0;
  if(fl=='a'){for(const o of B.units)if(o.s==u.s&&Math.hypot(o.x-u.x,o.y-u.y)<2.5)o.haste=.6}
  if(fl=='v'){for(const b of B.bld)if(!b.dead&&DEF_TYPES.includes(b.t)&&distRect(b,u.x,u.y)<3.2)b.slow=.6;for(const o of B.units)if(o.s!=u.s&&Math.hypot(o.x-u.x,o.y-u.y)<2.5)o.slow=.6}
  if(fl=='w'){u.fear=(u.fear||0)+.4;if(u.fear>=5){u.fear=0;let n=0;for(const b of B.bld)if(!b.dead&&DEF_TYPES.includes(b.t)&&distRect(b,u.x,u.y)<6){b.bl=2.2;n++}if(n)fxNum(B,u.x,u.y-.8,'СТРАХ!','#c7a0ff')}}}}
 if(fl=='y'&&u.s==0&&((u.t*4|0)%2==0)){for(const o of B.units)if(o.s!=u.s&&o.hp>0&&!o.fly&&Math.hypot(o.x-u.x,o.y-u.y)<.9)o.fire=2.5}
 if(fl=='c'&&u.hp<u.mx/2&&!u.rage){u.rage=1;u.dmg*=1.5;u.sp*=1.3;burst(B,u.x,u.y,'#ff4040',10,3)}
 // цель
 u.rt-=dt;u.fbt-=dt;if(u.fbt<=0)u.fb=null;
 if(!u.tg||u.rt<=0||(u.tk=='b'?u.tg.dead:u.tg.hp<=0)){pickTarget(B,u);u.rt=.45}
 if(!u.tg){if(u.home&&Math.hypot(u.home[0]-u.x,u.home[1]-u.y)>.6)stepMove(B,u,u.home[0],u.home[1],dt);return}
 const t=u.tg;let d;if(u.tk=='b')d=distRect(t,u.x,u.y);else d=Math.hypot(t.x-u.x,t.y-u.y)-.25;
 const reach=u.fl=='l'?1.4:u.rng;
 if(d>reach){const tx=u.tk=='b'?Math.max(t.x,Math.min(t.x+t.w,u.x)):t.x,ty=u.tk=='b'?Math.max(t.y,Math.min(t.y+t.w,u.y)):t.y;
  const aim=u.tk=='b'&&(tx==u.x||ty==u.y)?[tx,ty]:[u.tk=='b'?t.cx:t.x,u.tk=='b'?t.cy:t.y];stepMove(B,u,aim[0],aim[1],dt);return}
 // атака / поддержка
 if(u.fl=='l'){u.ac-=dt;if(u.ac<=0){u.ac=.5;for(const o of B.units)if(o.s==u.s&&o.hp>0&&o.hp<o.mx&&Math.hypot(o.x-u.x,o.y-u.y)<3){o.hp=Math.min(o.mx,o.hp+16*u.lv);fxNum(B,o.x,o.y,'+','#7dff9a')}}return}
 u.ac-=dt*(u.slow>0?.6:1);if(u.ac>0)return;if(!u.dmg){u.ac=1;return}u.ac=u.cd;u.mv=0;
 if(u.hid){u.hid=0;fxRing(B,u.x,u.y,'#fff')}
 let dm=u.dmg*(u.flash>0&&0?1:1);if(u.fl=='r'&&u.run>=4){dm*=2;u.run=0;burst(B,u.x,u.y,'#ffd23f',10,3)}u.run=0;
 if(u.fl=='k'){const r=2;for(const b of B.bld)if(!b.dead&&!isDeco(b.t)&&!TRAPS.includes(b.t)&&distRect(b,u.x,u.y)<r)dmgBuilding(B,b,u.dmg,u);for(const o of B.units)if(o.s!=u.s&&o.hp>0&&Math.hypot(o.x-u.x,o.y-u.y)<r)dmgUnit(B,o,u.dmg);
  burst(B,u.x,u.y,'#f4e2b0',26,4.5);fxRing(B,u.x,u.y,'#ffd27a');B.shake=Math.max(B.shake,9);snd('boom');u.hp=0;u.dead=1;if(u.s==0)B.lost++;return}
 if(u.ranged||u.fl=='b'&&false){B.proj.push({x0:u.x,y0:u.y,x1:t.x,y1:t.y,tg:t,tk:u.tk,u,t:0,d:Math.max(.1,d/9),k:'u',dmg:dm,side:0,splash:0});snd('shoot');onHitFx(B,u,t,u.tk);return}
 if(u.tk=='b')dmgBuilding(B,t,dm,u);else dmgUnit(B,t,dm,u);snd('hit');burst(B,t.cx||t.x,t.cy||t.y,'#fff',3,2);onHitFx(B,u,t,u.tk);
 if(u.fl=='m'||u.fl=='s'){splashAt(B,t.cx||t.x,t.cy||t.y,1.5,dm*.6,u.s,.6);fxRing(B,t.cx||t.x,t.cy||t.y,'#d8c9a0')}}
function onHitFx(B,u,t,tk){const fl=u.fl;
 if(tk=='b'){if(fl=='i')t.slow=3;if(fl=='d')t.deb=4;if(fl=='y')t.burn=3;if(fl=='f'){u.flc=(u.flc||0)+1;if(u.flc%3==0){for(const b of B.bld)if(!b.dead&&DEF_TYPES.includes(b.t)&&distRect(b,t.cx,t.cy)<3)b.bl=1.6;fxRing(B,t.cx,t.cy,'#fff')}}return}
 if(fl=='i')t.slow=3;if(fl=='o'){t.wet=3;t.slow=1.5}if(fl=='q'){const a=Math.atan2(t.y-u.y,t.x-u.x);t.x+=Math.cos(a)*.8;t.y+=Math.sin(a)*.8}if(fl=='d')t.slow=2;if(fl=='f')t.st=.8}
function stepMove(B,u,tx,ty,dt){const dx=tx-u.x,dy=ty-u.y,L=Math.hypot(dx,dy)||1;
 const sp=u.sp*(u.slow>0?.5:1)*(u.haste>0?1.3:1)*(u.fl=='m'?1:1),step=Math.min(L,sp*dt);const a0=Math.atan2(dy,dx);u.mv=1;
 if(u.fly||u.s==2){u.x+=dx/L*step;u.y+=dy/L*step;u.face=dx>=0?1:-1;u.run+=step;return}
 const cand=[0,.5,-.5,1,-1,1.6,-1.6];let moved=0;
 for(let k=0;k<cand.length;k++){const a=a0+cand[k],nx=u.x+Math.cos(a)*step,ny=u.y+Math.sin(a)*step;if(!solidAt(B,nx,ny,u)){u.x=nx;u.y=ny;u.face=Math.cos(a)>=0?1:-1;u.run+=step;moved=1;if(k>0)u.stk+=dt;else u.stk=Math.max(0,u.stk-dt*2);break}}
 if(!moved)u.stk+=dt*1.5;
 if(u.stk>1.2){u.stk=0;const bl=nearestB(B,u,b=>!TRAPS.includes(b.t)&&!isDeco(b.t)&&!(u.fl=='h'&&b.t=='wall')&&distRect(b,u.x,u.y)<1.8);if(bl){u.fb=bl;u.fbt=3;u.tg=bl;u.tk='b';u.rt=1}}
 // мягкое расталкивание
 if(B.units.length<70)for(const o of B.units){if(o===u||o.hp<=0||o.fly!=u.fly)continue;const ox=u.x-o.x,oy=u.y-o.y,dd=ox*ox+oy*oy;if(dd<.1&&dd>1e-4){const k=.02/Math.sqrt(dd);const nx=u.x+ox*k,ny=u.y+oy*k;if(!solidAt(B,nx,ny,u)){u.x=nx;u.y=ny}}}}
// ===== подготовленные базы противников =====
function ring(x0,y0,x1,y1,l,skip){const o=[];for(let x=x0;x<=x1;x++)for(let y=y0;y<=y1;y++)if(x==x0||x==x1||y==y0||y==y1){if(skip&&skip.some(s=>s[0]==x&&s[1]==y))continue;o.push(['wall',x,y,l])}return o}
const BASES=[
 {id:'b1',name:'Лагерь Пети',th:1,diff:'Очень лёгкая',gold:420,chek:260,cups:10,guards:[],
  layout:[['residence',18,18,1],['gold_mine',12,18,1],['chek_factory',12,23,1],['barracks',25,23,1],['cannon',23,17,1],['gold_mine',25,13,1],['tree',20,26,1],['tree',15,28,1]]},
 {id:'b2',name:'Дача новичка',th:1,diff:'Лёгкая',gold:650,chek:380,cups:14,guards:[[1,2]],
  layout:[['residence',17,17,1],...ring(14,14,23,23,1,[[18,23],[19,23]]),['cannon',15,19,2],['cannon',21,15,2],['gold_mine',8,16,2],['chek_factory',26,17,2],['barracks',17,26,1],['gold_mine',17,8,1],['cannon',11,22,1]]},
 {id:'b3',name:'Усадьба Тёти Любы',th:2,diff:'Средняя',gold:1100,chek:720,cups:20,guards:[[1,3],[12,1]],
  layout:[['residence',18,18,2],...ring(15,15,24,24,2,[[19,24],[20,24]]),['mel_tower',16,16,2],['mel_tower',22,22,2],['cannon',21,16,2],['cannon',16,21,2],['gold_store',9,17,2],['chek_store',28,17,2],['gold_mine',9,25,2],['chek_factory',27,26,2],['barracks',18,28,1],['lab',18,9,1],['hate_trap',13,13,2],['hate_trap',26,13,2],['camp',25,7,2]]},
 {id:'b4',name:'Форт Дяди Васи',th:3,diff:'Сложная',gold:2100,chek:1400,cups:28,guards:[[1,4],[31,1],[3,2]],
  layout:[['residence',18,18,3],...ring(13,13,26,26,3,[[19,26],[20,26]]),['mel_tower',15,15,3],['mod_tower',23,15,2],['meme_factory',15,22,2],['cannon',23,22,3],['hate_trap',17,17,3],['hate_trap',22,17,3],['hate_trap',19,22,3],['cannon',15,19,3],['mel_tower',23,19,3],
   ['gold_store',7,17,3],['chek_store',30,17,3],['gold_mine',7,25,3],['chek_factory',30,25,3],['sub_square',18,30,2],['barracks',24,30,2],['hate_trap',11,20,3],['hate_trap',28,13,3],['hate_trap',20,29,3],['hate_trap',20,10,3],['camp',8,7,3],['lab',26,6,2]]},
 {id:'b5',name:'Цитадель Хейтеров',th:4,diff:'Очень сложная',gold:3600,chek:2400,cups:38,guards:[[10,1],[1,5],[31,1],[34,2]],
  layout:[['residence',18,18,4],...ring(17,17,22,22,3),...ring(12,12,27,27,4,[[19,12],[20,12]]),['cannon',13,13,4],['mel_tower',25,13,4],['meme_factory',13,24,3],['mod_tower',25,24,3],['cannon',13,19,4],['mel_tower',25,19,4],['cannon',19,13,4],['meme_factory',19,24,3],
   ['spam_trap',16,16,3],['hate_trap',23,16,4],['hate_trap',16,23,4],['hate_trap',23,23,4],['hate_trap',15,18,4],['hate_trap',24,18,4],['chek_house',13,16,2],
   ['gold_store',5,17,4],['chek_store',32,17,4],['gold_mine',5,24,4],['chek_factory',32,24,4],['sub_square',18,31,3],['sub_square',22,5,3],['camp',5,6,4],['barracks',27,31,3],['lab',10,31,3],['hate_trap',9,12,4],['hate_trap',30,12,4]]}
];
const ARENA_BASE={id:'arena',name:'Испытание хайпа',th:4,diff:'Босс-арена',gold:6000,chek:4000,cups:60,arena:1,guards:[[10,1,2],[31,1,2],[1,6,2],[34,2,2]],
 layout:[['residence',18,18,5],...ring(17,17,22,22,5),...ring(11,11,28,28,5,[[19,11],[20,11]]),['cannon',12,12,5],['mel_tower',26,12,5],['meme_factory',12,25,5],['mod_tower',26,25,5],['cannon',12,19,5],['mel_tower',26,19,5],['cannon',19,12,5],['meme_factory',19,25,5],['mod_tower',14,15,4],['mel_tower',23,15,5],
  ['spam_trap',16,16,4],['hate_trap',23,17,5],['hate_trap',16,23,5],['hate_trap',23,23,5],['hate_trap',14,18,5],['hate_trap',25,18,5],['gold_store',5,16,5],['chek_store',32,16,5],['gold_mine',5,24,5],['chek_factory',32,24,5],['camp',5,6,5],['sub_center',16,31,3]]};
function pickBase(excludeId){const th=thLevel();const pool=BASES.filter(b=>b.th<=th&&b.id!=excludeId);const p=pool.length?pool:BASES.filter(b=>b.th<=th);
 // чем больше кубков, тем жёстче соперник
 const idx=Math.min(p.length-1,Math.floor(Math.random()*p.length*.7+(S.cups/120)*p.length*.5));const b=p[Math.max(0,idx)];
 const k=.85+Math.random()*.3;return Object.assign({},b,{gold:Math.round(b.gold*k),chek:Math.round(b.chek*k)})}
// учебный набег на твою базу: армия бота по кубкам
function raidScript(){const th=thLevel(),n=6+th*3+Math.min(10,S.cups/25|0),out=[];const pool=th>=3?[1,12,3,16,20,2,10,31,14,17]:[1,12,8,11,3,14,2];let t=1;
 const side=Math.random()*4|0;for(let k=0;k<n;k++){const i=pool[Math.random()*pool.length|0];let x,y;const r=3+Math.random()*33;if(side==0){x=r;y=3.2}else if(side==1){x=r;y=36.8}else if(side==2){x=3.2;y=r}else{x=36.8;y=r}
  out.push({t:t,u:i,x,y,l:Math.min(5,1+(th>>1))});t+=.35}return out}
