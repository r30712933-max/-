// art.js — процедурная изометрическая графика зданий (Canvas). Единый стиль:
// свет сверху-слева, толстые тёмные контуры, фиолетово-золотая палитра.
const ART_SCALE=2;
const K={pu:['#9a6cf0','#7648d0','#4d2c9c'],pd:['#6a45b8','#4a2d90','#2f1b62'],go:['#ffe46a','#ffc21f','#c98a0c'],st:['#d3cedf','#a29db5','#736e8c'],sd:['#8f8aa6','#6b6684','#4b4762'],
 rd:['#ff7a7a','#e63946','#a82234'],wd:['#c58f5c','#94603a','#654023'],bk:['#5a5470','#3d3852','#2a2640'],gl:['#bfe9ff','#79c6f0','#4a95c4'],gn:['#6fcf4e','#4fb03a','#388a2a'],wh:['#ffffff','#eeeaf8','#cfc9e6']};
const OUT='#2b1246';
let g,CUR;                                     // текущий контекст и размер здания
const iso=(u,v,z)=>[(u-v)*32,(u+v)*16-(z||0)];
function poly(p,f,lw){g.beginPath();p.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();if(f){g.fillStyle=f;g.fill()}g.lineWidth=lw||3;g.strokeStyle=OUT;g.lineJoin='round';g.stroke()}
function box(u0,v0,u1,v1,z0,z1,c){
 poly([iso(u0,v1,z0),iso(u1,v1,z0),iso(u1,v1,z1),iso(u0,v1,z1)],c[1]);
 poly([iso(u1,v0,z0),iso(u1,v1,z0),iso(u1,v1,z1),iso(u1,v0,z1)],c[2]);
 poly([iso(u0,v0,z1),iso(u1,v0,z1),iso(u1,v1,z1),iso(u0,v1,z1)],c[0])}
function hip(u0,v0,u1,v1,z,hz,c){const a=iso((u0+u1)/2,(v0+v1)/2,z+hz);
 poly([iso(u0,v1,z),iso(u1,v1,z),a],c[1]);poly([iso(u1,v0,z),iso(u1,v1,z),a],c[2])}
function gable(u0,v0,u1,v1,z,hz,c){const vm=(v0+v1)/2;
 poly([iso(u1,v0,z),iso(u1,v1,z),iso(u1,vm,z+hz)],c[2]);
 poly([iso(u0,v1,z),iso(u1,v1,z),iso(u1,vm,z+hz),iso(u0,vm,z+hz)],c[1])}
function ell(x,y,rx,ry,f,lw){g.beginPath();g.ellipse(x,y,rx,ry,0,0,7);if(f){g.fillStyle=f;g.fill()}if(lw!==0){g.lineWidth=lw||3;g.strokeStyle=OUT;g.stroke()}}
function cyl(u,v,r,z0,z1,c){const[x,by]=iso(u,v,z0),ty=iso(u,v,z1)[1],rx=r*45,ry=r*22.5;
 g.beginPath();g.moveTo(x-rx,ty);g.lineTo(x-rx,by);g.ellipse(x,by,rx,ry,0,Math.PI,0,true);g.lineTo(x+rx,ty);g.closePath();g.fillStyle=c[1];g.fill();g.lineWidth=3;g.strokeStyle=OUT;g.stroke();
 g.fillStyle=c[2];g.beginPath();g.moveTo(x+rx*.35,ty+ry*.9);g.lineTo(x+rx,ty);g.lineTo(x+rx,by);g.ellipse(x,by,rx,ry,0,0,Math.PI*.62);g.closePath();g.globalAlpha=.55;g.fill();g.globalAlpha=1;
 ell(x,ty,rx,ry,c[0])}
function onL(v1,u0,z0,fn){const[x,y]=iso(u0,v1,z0);g.save();g.transform(1,.5,0,-1,x,y);fn();g.restore()}
function onR(u1,v0,z0,fn){const[x,y]=iso(u1,v0,z0);g.save();g.transform(-1,.5,0,-1,x,y);fn();g.restore()}
function rr(x,y,w,h,r,f,lw){g.beginPath();g.roundRect(x,y,w,h,r);if(f){g.fillStyle=f;g.fill()}g.lineWidth=lw||2.5;g.strokeStyle=OUT;g.stroke()}
function crown(x,y,s,c){c=c||K.go;g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(-18,0);g.lineTo(-20,-22);g.lineTo(-9,-11);g.lineTo(0,-26);g.lineTo(9,-11);g.lineTo(20,-22);g.lineTo(18,0);g.closePath();g.fillStyle=c[1];g.fill();g.lineWidth=3/s;g.strokeStyle=OUT;g.lineJoin='round';g.stroke();
 g.fillStyle=c[0];g.fillRect(-16,-6,32,4);[[-20,-22],[0,-26],[20,-22]].forEach(p=>{g.beginPath();g.arc(p[0],p[1],3,0,7);g.fillStyle=K.rd[1];g.fill()});g.restore()}
function flag(u,v,z,h,col){const[x,y]=iso(u,v,z);g.lineWidth=3;g.strokeStyle=OUT;g.beginPath();g.moveTo(x,y);g.lineTo(x,y-h);g.stroke();g.lineWidth=1.5;g.strokeStyle='#d9d4e8';g.stroke();
 poly([[x,y-h],[x+24,y-h+6],[x,y-h+14]],col||K.pu[1],2.5);g.fillStyle='#fff';g.font='bold 8px sans-serif';g.textAlign='center';g.fillText('M',x+8,y-h+10)}
function melFace(x,y,s){ // лицо Мэла в очках
 g.save();g.translate(x,y);g.scale(s,s);ell(0,0,13,15,'#f0b98c',2.5);g.beginPath();g.moveTo(-14,-6);g.quadraticCurveTo(0,-26,14,-6);g.lineTo(14,-9);g.quadraticCurveTo(0,-24,-14,-9);g.closePath();g.fillStyle='#5a3220';g.fill();g.stroke();
 g.fillStyle='#111';g.fillRect(-12,-5,10,6);g.fillRect(2,-5,10,6);g.fillRect(-3,-4,6,2);g.fillStyle='#a02020';g.fillRect(-5,7,10,2.5);g.restore()}
function bottle(x,y,s,face){g.save();g.translate(x,y);g.scale(s,s);rr(-12,-34,24,34,6,'#b8610f');g.fillStyle='#e08b2a';g.fillRect(-9,-31,6,28);rr(-5,-52,10,20,3,'#a35510');rr(-7,-58,14,8,2,K.rd[1]);if(face)melFace(0,-16,.55);g.restore()}
function trollFace(x,y,s){g.save();g.translate(x,y);g.scale(s,s);ell(0,0,22,20,'#fff',3);g.fillStyle='#111';ell(-8,-6,3,3,'#111',0);ell(8,-6,3,3,'#111',0);g.lineWidth=2.5;g.strokeStyle='#111';g.beginPath();g.moveTo(-14,-12);g.lineTo(-3,-10);g.moveTo(14,-12);g.lineTo(3,-10);g.stroke();
 g.beginPath();g.moveTo(-15,3);g.quadraticCurveTo(0,22,15,3);g.quadraticCurveTo(0,8,-15,3);g.fillStyle='#fff';g.fill();g.stroke();g.beginPath();g.moveTo(-10,6);g.lineTo(10,6);g.stroke();g.restore()}
function door(v1,u0,w,h,col){onL(v1,u0,0,()=>{g.beginPath();g.moveTo(0,0);g.lineTo(0,h-w/2);g.arc(w/2,h-w/2,w/2,Math.PI,0);g.lineTo(w,0);g.closePath();g.fillStyle=col||'#3a1f12';g.fill();g.lineWidth=2.5;g.strokeStyle=OUT;g.stroke()})}
function win(side,a,b,z,w,h){const f=()=>{rr(0,0,w,h,3,'#ffd84a');g.fillStyle='#ff9a1f';g.fillRect(w/2-1,0,2,h);g.fillRect(0,h/2-1,w,2)};side=='L'?onL(a,b,z,f):onR(a,b,z,f)}
let NOPAD=false;
function pad(n){const h=n/2,p=[iso(-h,-h,0),iso(h,-h,0),iso(h,h,0),iso(-h,h,0)];
 if(NOPAD){poly(p,'rgba(20,60,20,.22)',0.01);g.save();g.beginPath();p.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();g.fillStyle='rgba(10,40,10,.18)';g.fill();g.restore();return}
 poly([iso(-h,h,-9),iso(h,h,-9),iso(h,h,0),iso(-h,h,0)],'#7a4a2a');poly([iso(h,-h,-9),iso(h,h,-9),iso(h,h,0),iso(h,-h,0)],'#5a331c');
 poly(p,'#66c24a');g.save();g.beginPath();p.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.clip();
 for(let i=0;i<n;i++)for(let j=0;j<n;j++)if((i+j)%2){const a=iso(-h+i,-h+j,0),b=iso(-h+i+1,-h+j,0),c=iso(-h+i+1,-h+j+1,0),d=iso(-h+i,-h+j+1,0);g.beginPath();g.moveTo(...a);g.lineTo(...b);g.lineTo(...c);g.lineTo(...d);g.closePath();g.fillStyle='rgba(30,120,30,.16)';g.fill()}
 g.restore();g.lineWidth=3;g.strokeStyle=OUT;g.beginPath();p.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();g.stroke();
 g.fillStyle='#4aa032';[[-.7,.2],[.5,-.6],[.1,.8],[-.2,-.9]].forEach(([a,b])=>{const q=iso(a*h*.9,b*h*.9,0);ell(q[0],q[1],7,3.5,'#3f9a2d',0)})}
function path(n){const h=n/2;poly([iso(.15,h,0),iso(-.15,h,0),iso(-.15,h*.2,0),iso(.15,h*.2,0)],'#e2c58a',2)}
// ---------- здания ----------
const ART={
residence(l){pad(4);const s=[.95,1.1,1.2,1.3,1.45][l-1],zh=[36,44,50,56,62][l-1];
 if(l>=5){g.save();g.globalAlpha=.35;const gr=g.createRadialGradient(0,-90,10,0,-90,150);gr.addColorStop(0,'#fff6a0');gr.addColorStop(1,'rgba(255,220,80,0)');g.fillStyle=gr;g.fillRect(-170,-260,340,300);g.restore()}
 path(4);
 if(l>=4)[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([a,b],i)=>{const q=s+.35;box(a*q-.28,b*q-.28,a*q+.28,b*q+.28,0,zh+14,K.st);hip(a*q-.34,b*q-.34,a*q+.34,b*q+.34,zh+14,16,K.go);if(l>=5)crown(iso(a*q,b*q,zh+30)[0],iso(a*q,b*q,zh+30)[1],.5)});
 box(-s,-s,s,s,0,zh,K.st);
 const t=s*.78;box(-s-.05,-s-.05,s+.05,s+.05,zh-3,zh+3,K.go);box(-t,-t,t,t,zh+3,zh+26,K.pu);
 if(l==1){hip(-t-.1,-t-.1,t+.1,t+.1,zh+26,22,K.pd);flag(t*.5,-t*.5,zh+40,34)}
 else if(l==2){hip(-t-.1,-t-.1,t+.1,t+.1,zh+26,26,K.pu);box(-t-.05,-t-.05,t+.05,t+.05,zh+22,zh+28,K.go);flag(t*.5,-t*.5,zh+46,38)}
 else{const u=t*.62;box(-u,-u,u,u,zh+26,zh+44,K.pu);box(-u-.04,-u-.04,u+.04,u+.04,zh+40,zh+46,K.go);const c=iso(0,0,zh+46);crown(c[0],c[1]-1,l>=4?1.6:1.25);if(l>=5)crown(c[0],c[1]-34,.8);flag(u,-u,zh+46,40)}
 door(s,-.35,34,40,'#4a2412');onL(s,-.35,0,()=>{g.fillStyle=K.rd[1];g.fillRect(6,0,22,6)});
 win('L',s,-.95*s,zh*.5,16,18);win('L',s,.55*s,zh*.5,16,18);win('R',s,-.2*s,zh*.5,16,18);
 if(l>=4){onL(s,-.9*s,zh+2,()=>{});const p=iso(-t*.55,t,zh+13);ell(p[0],p[1],19,19,K.go[1],3);g.fillStyle=OUT;g.font='bold 24px sans-serif';g.textAlign='center';g.fillText('M',p[0],p[1]+8)}
 else{const p=iso(-t*.5,t,zh+12);g.fillStyle=K.go[1];g.font='bold 18px sans-serif';g.textAlign='center';g.strokeStyle=OUT;g.lineWidth=3;g.strokeText('M',p[0],p[1]+6);g.fillText('M',p[0],p[1]+6)}},
barracks(){pad(3);box(-.9,-.7,.9,.7,0,34,K.wd);gable(-1.05,-.9,1.05,.9,34,30,K.rd);const p=iso(.2,.1,52);rr(p[0]-14,p[1]-13,28,22,4,'#fff');g.fillStyle=K.rd[1];g.font='bold 18px sans-serif';g.textAlign='center';g.fillText('M',p[0],p[1]+4);
 door(.7,-.5,26,30);win('R',.9,-.2,14,14,14);flag(-.9,.2,34,48,K.rd[1]);cyl(1.05,-.1,.18,0,18,K.wd);box(-1.2,-.1,-1,.3,0,12,K.wd)},
lab(){pad(3);box(-1,-1,1,1,0,30,K.st);box(-.8,-.8,.8,.8,30,40,K.pu);door(1,-.3,24,28,'#2b1a4a');win('L',1,.35,12,14,12);win('R',1,-.6,12,14,12);
 const p=iso(0,0,40);g.save();g.translate(p[0],p[1]);rr(-8,-46,16,30,3,'#d8f6ff');ell(0,-14,26,22,'rgba(110,230,120,.95)');g.fillStyle='#b9ffb0';ell(-8,-18,5,5,'#cfffc8',0);ell(8,-8,4,4,'#cfffc8',0);ell(2,-26,3,3,'#cfffc8',0);rr(-12,-52,24,8,3,K.go[1]);g.restore()},
camp(){pad(4);ell(0,4,50,25,'#8a5a34');ell(0,0,38,19,'#3a2a22');ell(0,-4,14,8,'#ff9a1f');ell(0,-8,8,14,'#ffd84a',2);ell(0,-10,3,8,'#fff6b0',0);
 [[-1.15,.55,K.rd],[1.1,-.2,K.pu],[-.2,-1.25,K.go],[.55,1.1,K.rd]].forEach(([u,v,c])=>{box(u-.34,v-.34,u+.34,v+.34,0,10,K.wd);hip(u-.5,v-.5,u+.5,v+.5,10,34,c);flag(u,v,44,18,c[1])})},
gold_mine(){pad(3);box(-1,-1,1,.8,0,36,K.sd);box(-.8,-.8,.7,.4,36,50,K.st);door(.8,-.45,30,32,'#120a18');onL(.8,-.45,0,()=>{g.fillStyle=K.wd[1];g.fillRect(-4,28,38,5);g.fillRect(-4,0,4,33);g.fillRect(34,0,4,33)});
 for(let i=0;i<7;i++){const q=iso(.55+(i%3)*.17-.4,-.6+(i/3|0)*.14+.1,0);ell(q[0]+10,q[1]-2-(i%2)*3,7,6,K.go[1])}
 box(.65,-.9,1.05,-.45,0,14,K.bk);cyl(.85,-.68,.2,14,18,K.go);ell(iso(-.4,-.3,52)[0],iso(-.4,-.3,52)[1],10,7,K.go[0])},
chek_factory(){pad(3);box(-1,-.9,1,.9,0,34,K.pd);box(-.9,-.8,.9,.8,34,40,K.pu);door(.9,-.55,24,26,'#2a1230');onL(.9,-.55,0,()=>{g.fillStyle=K.rd[1];g.fillRect(4,0,16,5)});win('R',1,-.2,12,14,14);
 cyl(-.8,-.55,.2,34,64,K.sd);cyl(.75,-.75,.18,34,56,K.sd);box(.4,.1,.8,.5,0,20,K.wd);const p=iso(0,-.1,40);bottle(p[0],p[1],1.35,true)},
gold_store(){pad(3);box(-1,-1,1,1,0,34,K.st);box(-.85,-.85,.85,.85,28,36,K.sd);for(let i=0;i<9;i++){const a=i%3-1,b=(i/3|0)-1;cyl(a*.5,b*.5,.24,34,40+(i%4)*5,K.go)}
 onL(1,-.4,6,()=>{rr(0,0,38,24,5,K.pu[1]);g.fillStyle=OUT;g.font='bold 15px sans-serif';g.fillText('$',14,18)});crown(iso(0,0,76)[0],iso(0,0,76)[1],.7)},
chek_store(){pad(3);box(-1,-1,1,1,0,30,K.pd);box(-.9,-.9,.9,.9,30,36,K.wd);for(let i=0;i<7;i++){const a=(i%3-1)*.5,b=((i/3|0)-.5)*.5;const p=iso(a,b,36);bottle(p[0],p[1],.85+((i*7)%3)*.05,false)}
 onL(1,-.5,5,()=>{rr(0,0,44,26,5,K.pu[1]);crown(22,22,.55)})},
sub_square(){pad(3);box(-1,-.9,1,.9,0,22,K.bk);box(-1.05,-.2,.9,.8,22,30,K.pd);
 onL(.9,-.95,24,()=>{rr(0,0,62,50,5,K.pu[1],3);g.fillStyle='#4aa0f0';g.fillRect(6,6,50,38);g.fillStyle='#bfe0ff';g.fillRect(6,6,50,10)});const p=iso(-.62,.9,40);melFace(p[0]+2,p[1]-2,1.05);
 onR(1,-.7,8,()=>{rr(0,0,26,22,4,K.pu[1]);g.fillStyle='#fff';g.beginPath();g.moveTo(8,5);g.lineTo(8,17);g.lineTo(19,11);g.fill()});
 cyl(.3,-.2,.1,30,50,K.sd);const d=iso(.3,-.2,56);g.save();g.translate(d[0],d[1]);g.rotate(-.5);ell(0,0,26,12,'#e8e4f2');ell(3,2,18,8,'#bdb8d0',0);g.restore()},
mel_tower(){pad(2);box(-.7,-.7,.7,.7,0,20,K.st);box(-.5,-.5,.5,.5,20,74,K.pd);box(-.62,-.62,.62,.62,74,86,K.go);box(-.5,-.5,.5,.5,86,92,K.st);
 const p=iso(-.2,.5,56);melFace(p[0]+4,p[1],.95);win('L',.5,-.35,36,10,12);win('R',.5,-.15,36,10,12);crown(iso(0,0,92)[0],iso(0,0,92)[1],1.1)},
cannon(){pad(2);box(-.7,-.7,.7,.7,0,14,K.st);box(-.45,-.45,.45,.45,14,22,K.pd);const b=iso(0,0,34);g.save();g.translate(b[0],b[1]);g.rotate(.45);rr(-46,-13,70,26,10,K.sd,3.5);g.fillStyle='#2a2640';g.fillRect(20,-11,6,22);rr(-48,-15,14,30,6,K.go[1],3);rr(-10,-15,10,30,3,K.go[1],3);ell(24,0,5,11,'#16102a',2);g.restore();ell(b[0]-4,b[1]+8,16,10,K.pd[1]);crown(b[0]+18,b[1]-6,.6)},
meme_factory(){pad(3);box(-1,-1,1,1,0,26,K.sd);box(-.85,-.85,.85,.85,26,48,K.st);box(-1,-1,1,1,24,29,K.pu);onL(.85,-.45,26,()=>{});const p=iso(-.1,.85,38);trollFace(p[0],p[1]+1,1.15);
 cyl(.55,-.55,.18,48,72,K.wd);cyl(-.6,-.5,.14,48,66,K.sd);box(.2,.3,.7,.75,0,16,K.pu);door(1,.2,22,24,'#241636');win('R',.85,-.1,28,12,12)},
mod_tower(){pad(2);box(-.7,-.7,.7,.7,0,18,K.st);box(-.52,-.52,.52,.52,18,64,K.pu);box(-.64,-.64,.64,.64,64,74,K.rd);hip(-.7,-.7,.7,.7,74,22,K.pd);
 const p=iso(-.1,.52,44);g.save();g.translate(p[0],p[1]);ell(0,0,15,15,'#fff',3);g.strokeStyle=K.rd[1];g.lineWidth=5;g.beginPath();g.arc(0,0,10,0,7);g.moveTo(-7,-7);g.lineTo(7,7);g.stroke();g.restore();flag(.4,-.4,96,22,K.rd[1])},
hate_trap(){pad(1);box(-.38,-.38,.38,.38,0,10,K.bk);[[-.4,-.4],[.4,-.4],[-.4,.4],[.4,.4]].forEach(([a,b])=>{const p=iso(a,b,10);poly([[p[0]-5,p[1]],[p[0]+5,p[1]],[p[0],p[1]-18]],'#d9d4e8',2)});
 const p=iso(0,0,10);ell(p[0],p[1],14,7,'#a82234');ell(p[0],p[1]-5,12,6,'#ff4040');onL(.38,-.3,2,()=>{rr(0,0,32,12,2,K.rd[1],2);g.fillStyle='#fff';g.font='bold 9px sans-serif';g.fillText('ХЕЙТ',3,10)})},
spam_trap(){pad(1);box(-.36,-.36,.36,.36,0,8,K.pd);const p=iso(0,0,8);g.lineWidth=5;g.strokeStyle=OUT;g.beginPath();for(let i=0;i<5;i++){g.lineTo(p[0]+(i%2?10:-10),p[1]-4-i*6)}g.stroke();g.lineWidth=2.5;g.strokeStyle='#5ae0ff';g.stroke();ell(p[0],p[1]-34,14,8,K.go[1]);g.fillStyle=OUT;g.font='bold 12px sans-serif';g.textAlign='center';g.fillText('@',p[0],p[1]-30)},
wall(){pad(1);box(-.46,-.46,.46,.46,0,26,K.st);box(-.46,-.46,.46,.46,0,5,K.sd);const p=iso(.1,.46,16);rr(p[0]-8,p[1]-7,14,13,2,K.go[1],2);g.fillStyle=OUT;g.fillRect(p[0]-5,p[1]-1,8,3);box(-.46,-.46,-.1,-.1,26,34,K.st)},
chek_house(){pad(2);box(-.65,-.55,.65,.55,0,26,K.wd);gable(-.8,-.7,.8,.7,26,28,K.go);door(.55,-.35,20,22);win('R',.65,-.1,10,10,12);const p=iso(-.25,0,60);bottle(p[0],p[1],.9,true);flag(.5,-.4,40,24,K.pu[1])},
hype_arena(){pad(4);cyl(0,0,1.65,0,40,K.st);const t=iso(0,0,40);ell(t[0],t[1],58,29,'#3a2a5c');ell(t[0],t[1]+2,46,23,'#c9a56a');ell(t[0],t[1]-2,20,10,K.rd[1],2);g.fillStyle='#fff';g.font='bold 12px sans-serif';g.textAlign='center';g.fillText('ХАЙП',t[0],t[1]+1);
 [[-1.3,-1.3],[1.3,-1.3],[-1.3,1.3],[1.3,1.3]].forEach(([a,b],i)=>{box(a-.18,b-.18,a+.18,b+.18,0,64,K.go);flag(a,b,64,34,i%2?K.rd[1]:K.pu[1])})},
sub_center(){pad(3);box(-1,-1,1,1,0,26,K.st);box(-.8,-.8,.8,.8,26,66,K.pu);box(-.9,-.9,.9,.9,60,68,K.go);
 onL(.8,-.5,30,()=>{rr(0,0,64,34,6,'#fff');g.fillStyle=K.rd[1];g.beginPath();g.moveTo(24,6);g.lineTo(24,28);g.lineTo(44,17);g.fill()});crown(iso(0,0,68)[0],iso(0,0,68)[1],1.1);door(1,-.2,22,22,'#241636')},
tree(){pad(1);box(-.08,-.08,.08,.08,0,22,K.wd);const c=iso(0,0,38);ell(c[0],c[1]+6,24,18,'#3f9a2d');ell(c[0]-8,c[1]-4,18,15,'#58c040');ell(c[0]+9,c[1]-8,15,13,'#6fd652')},
flowers(){pad(1);[[-.2,-.1,'#ff5a8a'],[.2,0,'#ffd23f'],[0,.22,'#fff'],[-.1,.1,'#7ad0ff']].forEach(([a,b,c])=>{const p=iso(a,b,0);ell(p[0],p[1]-6,5,5,c,2);g.fillStyle='#2f8a2a';g.fillRect(p[0]-1,p[1]-6,2,6)})},
statue(){pad(2);box(-.55,-.55,.55,.55,0,16,K.st);box(-.4,-.4,.4,.4,16,24,K.sd);const p=iso(0,0,24);g.save();g.translate(p[0],p[1]);rr(-13,-40,26,40,9,K.go[1],3);rr(8,-34,12,20,6,K.go[0],2.5);ell(0,-52,13,14,K.go[0],3);g.fillStyle='#111';g.fillRect(-11,-56,22,6);g.restore()}
};
const artCache={};
function getArt(type,lvl,flip,nopad){const k=type+'_'+(lvl||1)+(flip?'f':'')+(nopad?'n':'');if(artCache[k])return artCache[k];
 const n=BD[type].w,W=n*64+56,above=n==4?250:n==3?200:n==2?170:130,H=above+n*16+16;
 const c=document.createElement('canvas');c.width=W*ART_SCALE;c.height=H*ART_SCALE;g=c.getContext('2d');g.scale(ART_SCALE,ART_SCALE);
 g.translate(W/2,above);NOPAD=!!nopad;
 ART[type](lvl||1);NOPAD=false;
 if(lvl>1&&type!='residence'||lvl>1&&false){const h=BD[type].w/2,q=iso(h-.4,h-.4,0);for(let i=0;i<lvl-1;i++){g.fillStyle=K.go[0];g.strokeStyle=OUT;g.lineWidth=3;g.font='bold 15px sans-serif';g.textAlign='center';const x=q[0]+(i-(lvl-2)/2)*13;g.strokeText('★',x,q[1]+4);g.fillText('★',x,q[1]+4)}}
 let out=c;if(flip){out=document.createElement('canvas');out.width=c.width;out.height=c.height;const o=out.getContext('2d');o.translate(c.width,0);o.scale(-1,1);o.drawImage(c,0,0)}
 return artCache[k]={c:out,w:W,h:H,ax:W/2,ay:above}}
