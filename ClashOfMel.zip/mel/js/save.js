// save.js — сохранение прогресса. Отдельный ключ, старые сохранения ML Royale не трогаем.
const SAVE_KEY='clash_of_mel_save_v1';
let S=null;
function newState(){
 const t=Date.now(),mk=(id,t_,x,y)=>({id,t:t_,x,y,l:1,flip:0,up:0,upTo:0,cons:0,acc:{gold:0,chek:0},stored:0});
 const st={v:1,gold:700,chek:450,cups:0,xp:0,nid:1,bld:[],army:{1:6,11:3},queue:[],ul:{},lab:null,ach:{},camp:{},opts:{vol:.8,mute:0},
  stats:{att:0,wins:0,stars:0,looted:0,defs:0},last:t,cam:null,seen:{},arenaDay:0};
 [['residence',18,17],['barracks',23,19],['gold_mine',13,13],['chek_factory',13,22],['cannon',23,14]].forEach(([k,x,y])=>{const b=mk(st.nid++,k,x,y);st.bld.push(b)});
 return st}
function saveGame(){if(!S)return;try{S.last=Date.now();localStorage.setItem(SAVE_KEY,JSON.stringify(S))}catch(e){}}
function loadGame(){let ok=false;try{const r=localStorage.getItem(SAVE_KEY);if(r){const o=JSON.parse(r);if(o&&o.v==1&&Array.isArray(o.bld)){S=Object.assign(newState(),o);ok=true}}}catch(e){}
 if(!S)S=newState();return ok}
function resetGame(){try{localStorage.removeItem(SAVE_KEY)}catch(e){}S=newState();saveGame()}
let _as=0;function startAutosave(){clearInterval(_as);_as=setInterval(saveGame,8000);window.addEventListener('pagehide',saveGame);document.addEventListener('visibilitychange',()=>{if(document.hidden)saveGame()})}
