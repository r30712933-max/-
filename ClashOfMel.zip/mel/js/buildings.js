// buildings.js — каталог зданий, статы по уровням, требования Резиденции
const TW=64,TH=32,GN=40,PAD=3;           // размер тайла (ромб), сторона карты, лесная кайма
const UPM=[1,2.2,5,11,24];                // множитель цены улучшения по уровню
const BD={
 residence:{n:'Резиденция Мэла',cat:'main',w:4,cost:0,bt:0,hp:900,cnt:[1,1,1,1,1],ml:[1,2,3,4,5],
  d:'Сердце базы. Её уровень открывает здания, бойцов и улучшения. Хранит часть ресурсов.',up:[0,0,400,1500,5000,14000],ut:[0,0,12,25,45,70]},
 barracks:{n:'Казармы',cat:'army',w:3,cost:150,bt:5,hp:380,cnt:[1,1,2,2,3],ml:[1,2,3,3,4],d:'Тренируют бойцов. Чем выше уровень, тем быстрее очередь.'},
 lab:{n:'Лаборатория мемов',cat:'army',w:3,cost:600,bt:12,hp:360,cnt:[0,1,1,1,1],ml:[0,1,2,3,3],d:'Улучшает бойцов: здоровье, урон, скорость и дальность.'},
 camp:{n:'Армейский лагерь',cat:'army',w:4,cost:300,bt:8,hp:400,cnt:[0,1,2,3,4],ml:[0,2,3,4,5],d:'Каждый лагерь добавляет места в армии.'},
 gold_mine:{n:'Золотая шахта',cat:'res',w:3,cost:120,bt:4,hp:350,cnt:[1,2,3,4,5],ml:[2,3,4,5,5],d:'Добывает золото. Нажми на готовую шахту, чтобы забрать.'},
 chek_factory:{n:'Фабрика чекушек',cat:'res',w:3,cost:150,bt:5,hp:350,cnt:[1,2,3,4,5],ml:[2,3,4,5,5],d:'Выпускает игровую валюту — чекушки (вымышленные, для тренировки бойцов).'},
 gold_store:{n:'Хранилище золота',cat:'res',w:3,cost:200,bt:6,hp:500,cnt:[0,1,2,3,3],ml:[0,2,3,4,5],d:'Увеличивает вместимость золота.'},
 chek_store:{n:'Хранилище чекушек',cat:'res',w:3,cost:200,bt:6,hp:500,cnt:[0,1,2,3,3],ml:[0,2,3,4,5],d:'Увеличивает вместимость чекушек.'},
 sub_square:{n:'Площадь подписчиков',cat:'res',w:3,cost:400,bt:8,hp:420,cnt:[0,1,1,2,2],ml:[0,2,3,4,5],d:'Подписчики несут и золото, и чекушки. Чем выше уровень, тем больше доход.'},
 mel_tower:{n:'Башня Мэла',cat:'def',w:2,cost:350,bt:8,hp:420,cnt:[0,1,2,2,3],ml:[0,2,3,4,5],d:'Быстро стреляет по земле и по воздуху.'},
 cannon:{n:'Пушка Дела',cat:'def',w:2,cost:200,bt:4,hp:450,cnt:[1,2,2,3,4],ml:[2,3,4,5,5],d:'Бьёт только по земле. Большой урон, медленная стрельба.'},
 meme_factory:{n:'Завод мемов',cat:'def',w:3,cost:700,bt:12,hp:520,cnt:[0,0,1,2,2],ml:[0,0,2,4,5],d:'Запускает мемные снаряды с уроном по площади.'},
 mod_tower:{n:'Башня модераторов',cat:'def',w:2,cost:900,bt:14,hp:460,cnt:[0,0,1,1,2],ml:[0,0,2,4,5],d:'Банит бойца: цель на пару секунд теряет контроль.'},
 hate_trap:{n:'Ловушка Хейта',cat:'def',w:1,cost:150,bt:3,hp:80,cnt:[0,1,2,3,4],ml:[0,2,3,4,5],d:'Скрытая ловушка. Взрывается, когда рядом оказывается наземный враг.'},
 spam_trap:{n:'Ловушка Спама',cat:'def',w:1,cost:500,bt:6,hp:80,cnt:[0,0,0,1,2],ml:[0,0,0,3,4],d:'Новая ловушка: оглушает всех вокруг на несколько секунд.'},
 wall:{n:'Стена Мэла',cat:'def',w:1,cost:25,bt:1,hp:160,cnt:[25,50,75,100,125],ml:[2,3,4,5,5],d:'Преграда для бойцов. Враги вынуждены её ломать или обходить.'},
 chek_house:{n:'Дом Чекушки',cat:'main',w:2,cost:800,bt:12,hp:400,cnt:[0,0,1,1,1],ml:[0,0,2,3,4],d:'Дом персонажа. +10% к добыче чекушек за уровень.'},
 hype_arena:{n:'Арена хайпа',cat:'main',w:4,cost:1500,bt:20,hp:700,cnt:[0,0,0,1,1],ml:[0,0,0,1,2],d:'Отдельный режим: «Испытание хайпа» против укреплённого соперника с двойной наградой.'},
 sub_center:{n:'Центр подписчиков',cat:'main',w:3,cost:1200,bt:16,hp:520,cnt:[0,0,0,1,1],ml:[0,0,0,2,3],d:'Бонус к кубкам и добыче с нападений за каждый уровень.'},
 tree:{n:'Дерево',cat:'deco',w:1,cost:20,bt:0,hp:30,cnt:[20,20,20,20,20],ml:[1,1,1,1,1],d:'Просто красиво. Не мешает врагам и не считается за разрушение.'},
 flowers:{n:'Клумба',cat:'deco',w:1,cost:30,bt:0,hp:30,cnt:[10,10,10,10,10],ml:[1,1,1,1,1],d:'Цветы для настроения.'},
 statue:{n:'Статуя Мэла',cat:'deco',w:2,cost:300,bt:0,hp:100,cnt:[1,2,3,4,5],ml:[1,1,1,1,1],d:'Золотой Мэл показывает большой палец.'}
};
const DEF_TYPES=['mel_tower','cannon','meme_factory','mod_tower'],TRAPS=['hate_trap','spam_trap'];
const isDeco=t=>BD[t].cat=='deco';
const countsAsTarget=t=>!isDeco(t)&&t!='wall'&&!TRAPS.includes(t);
function unlockTH(t){return BD[t].cnt.findIndex(c=>c>0)+1}
function maxCount(t,th){return BD[t].cnt[th-1]}
function maxLevel(t,th){return BD[t].ml[th-1]}
function upCost(t,l){const b=BD[t];return b.up?b.up[l]:Math.round(b.cost*UPM[l-1])}   // цена перехода НА уровень l
function upTime(t,l){const b=BD[t];return b.ut?b.ut[l]:Math.round(Math.max(3,b.bt)*[1,2,4,7,11][l-1])}
function bHp(t,l){return Math.round(BD[t].hp*Math.pow(1.38,l-1))}
function dStat(t,l){const g=Math.pow(1.3,l-1);
 switch(t){
  case 'cannon':return{dmg:70*g,rng:7.5,rate:1.5,air:0,spl:0};
  case 'mel_tower':return{dmg:26*g,rng:8.5,rate:.65,air:1,spl:0};
  case 'meme_factory':return{dmg:48*g,rng:8,rate:2.1,air:0,spl:1.8};
  case 'mod_tower':return{dmg:16*g,rng:7,rate:3.2,air:1,spl:0,ban:1.8};
  case 'hate_trap':return{dmg:170*g,rng:1.3,spl:1.7};
  case 'spam_trap':return{dmg:55*g,rng:1.3,spl:2.4,stun:3};
 }return{}}
function prod(t,l,hb){const g=Math.pow(1.38,l-1);hb=hb||1;
 if(t=='gold_mine')return{gold:1.7*g};
 if(t=='chek_factory')return{chek:1.2*g*hb};
 if(t=='sub_square')return{gold:.5*g,chek:.35*g*hb};return null}
const COLCAP=1800;                         // секунд выработки, которые копятся внутри здания (лимит оффлайна)
const resGold=l=>[1500,3500,8000,18000,40000][l-1],resChek=l=>[1000,2500,6000,14000,30000][l-1];
const storeCap=l=>Math.round(1600*Math.pow(1.7,l-1));
const campCap=l=>16+(l-1)*6;
const thName=['','Лачуга','Дом','Особняк','Дворец','Мемная крепость'];
