// world.js — карта, изометрическая камера и отрисовка (база и поле боя)
const IM={};for(const k in SPR){IM[k]=new Image();IM[k].src=SPR[k]}
const cam={x:0,y:GN*16,z:.8,min:.35,max:1.8};
let cvs,ctx,VW=360,VH=640,DPR=1;
const gIso=(gx,gy)=>[(gx-gy)*32,(gx+gy)*16];
const bw=b=>b.w||BD[b.t].w;
function screenToGrid(px,py){const wx=(px-VW/2)/cam.z+cam.x,wy=(py-VH/2)/cam.z+cam.y;return[(wy/16+wx/32)/2,(wy/16-wx/32)/2]}
function gridToScreen(gx,gy){const[x,y]=gIso(gx,gy);return[(x-cam.x)*cam.z+VW/2,(y-cam.y)*cam.z+VH/2]}
function clampCam(){const lim=GN*32;cam.z=Math.max(cam.min,Math.min(cam.max,cam.z));cam.x=Math.max(-lim*.85,Math.min(lim*.85,cam.x));cam.y=Math.max(40,Math.min(GN*32-40,cam.y))}
function resize(){DPR=Math.min(2,window.devicePixelRatio||1);VW=innerWidth;VH=innerHeight;cvs.width=VW*DPR;cvs.height=VH*DPR;cvs.style.width=VW+'px';cvs.style.height=VH+'px';
 cam.min=Math.max(.3,Math.min(VW/(GN*64*.9),.5))}
// ---- земля ----
let ground=null;const GX0=GN*32+16;
function buildGround(){const c=document.createElement('canvas');c.width=GN*64+32;c.height=GN*32+60;const g=c.getContext('2d');g.translate(GX0,10);
 const dia=(i,j,col)=>{const[x,y]=gIso(i,j);g.beginPath();g.moveTo(x,y);g.lineTo(x+32,y+16);g.lineTo(x,y+32);g.lineTo(x-32,y+16);g.closePath();g.fillStyle=col;g.fill()};
 // боковые «обрывы»
 g.fillStyle='#6b4224';g.beginPath();g.moveTo(-GN*32,GN*16);g.lineTo(0,GN*32);g.lineTo(0,GN*32+26);g.lineTo(-GN*32,GN*16+26);g.fill();g.fillStyle='#4a2c16';g.beginPath();g.moveTo(GN*32,GN*16);g.lineTo(0,GN*32);g.lineTo(0,GN*32+26);g.lineTo(GN*32,GN*16+26);g.fill();
 let seed=7;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
 for(let i=0;i<GN;i++)for(let j=0;j<GN;j++){const edge=i<PAD||j<PAD||i>=GN-PAD||j>=GN-PAD;dia(i,j,edge?((i+j)%2?'#2f8a3a':'#37963f'):((i+j)%2?'#6fcb4f':'#7dd95a'))}
 // цветочки и травинки
 for(let n=0;n<420;n++){const i=PAD+rnd()*(GN-2*PAD),j=PAD+rnd()*(GN-2*PAD),[x,y]=gIso(i,j);g.fillStyle=['#58b83e','#fff','#ffd23f','#ff8ab0'][n%4==0?1+(n>>2)%3:0];g.fillRect(x,y,n%4?2:3,n%4?3:3)}
 // лес по краю
 const trees=[];for(let i=0;i<GN;i++)for(let j=0;j<GN;j++){if(i<PAD||j<PAD||i>=GN-PAD||j>=GN-PAD)trees.push([i+.5+(rnd()-.5)*.5,j+.5+(rnd()-.5)*.5,rnd()])}
 trees.sort((a,b)=>a[0]+a[1]-b[0]-b[1]);
 for(const[i,j,r]of trees){const[x,y]=gIso(i,j),s=.8+r*.5;g.fillStyle='rgba(0,0,0,.2)';g.beginPath();g.ellipse(x,y+18,22*s,9*s,0,0,7);g.fill();g.fillStyle='#6b431f';g.fillRect(x-3*s,y-4*s,6*s,24*s);
  const col=['#2c8a3a','#37a046','#46b552'][r*3|0];g.fillStyle=col;g.strokeStyle='#14501f';g.lineWidth=2;for(const[dx,dy,rr]of[[0,-4,22],[-10,-18,18],[10,-20,17],[0,-34,15]]){g.beginPath();g.arc(x+dx*s,y+dy*s,rr*s,0,7);g.fill();g.stroke()}}
 ground=c}
// ---- рисование ----
function drawDia(c,gx,gy,w,fill,stroke,lw){const p=[gIso(gx,gy),gIso(gx+w,gy),gIso(gx+w,gy+w),gIso(gx,gy+w)];c.beginPath();p.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.closePath();if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.lineWidth=lw||2;c.strokeStyle=stroke;c.stroke()}}
function drawGrid(c){c.beginPath();for(let i=PAD;i<=GN-PAD;i++){let a=gIso(i,PAD),b=gIso(i,GN-PAD);c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);a=gIso(PAD,i);b=gIso(GN-PAD,i);c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1])}c.lineWidth=1;c.strokeStyle='rgba(255,255,255,.16)';c.stroke()}
function bar(c,x,y,w,f,col){c.fillStyle='#000a';c.fillRect(x-w/2-1,y-1,w+2,7);c.fillStyle=col;c.fillRect(x-w/2,y,w*Math.max(0,Math.min(1,f)),5)}
function fmtT(s){s=Math.max(0,Math.ceil(s));return s>=60?(s/60|0)+':'+('0'+s%60).slice(-2):s+'с'}
function drawBld(c,b,sc){const w=bw(b),[cx,cy]=gIso(b.x+w/2,b.y+w/2);let dead=b.dead;
 if(dead){const k=Math.min(1,(sc.t-(b.t0||0))/.45);if(k>=1||!sc.t){c.fillStyle='rgba(40,25,15,.55)';c.beginPath();c.ellipse(cx,cy,w*26,w*12,0,0,7);c.fill();c.fillStyle='#5a4a40';for(let i=0;i<4+w;i++){const a=i*2.1;c.beginPath();c.ellipse(cx+Math.cos(a)*w*14,cy+Math.sin(a)*w*6,5,3.5,0,0,7);c.fill()}return}}
 if(TRAPS.includes(b.t)&&sc.mode=='battle'&&!dead&&!sc.scout)return;
 const a=getArt(b.t,b.l,b.flip,1),k=dead?Math.min(1,(sc.t-b.t0)/.45):0;c.save();
 let ox=0;if(b.flash>0)ox=(Math.random()-.5)*3;
 if(dead){c.translate(cx,cy+30);c.scale(1,1-k);c.translate(-cx,-cy-30);c.globalAlpha=1-k*.6}
 if(sc.mode=='base'&&b.cons&&busy(b))c.globalAlpha=.55;
 if(sc.mode=='battle'&&TRAPS.includes(b.t))c.globalAlpha=.5;
 c.drawImage(a.c,cx-a.ax+ox,cy-a.ay,a.w,a.h);
 if(b.flash>0){c.globalAlpha=.4;c.globalCompositeOperation='lighter';c.drawImage(a.c,cx-a.ax,cy-a.ay,a.w,a.h);c.globalCompositeOperation='source-over'}
 c.restore();
 if(sc.mode=='base'){const t=nowMs();
  if(busy(b)){const tot=(b.cons?BD[b.t].bt:upTime(b.t,b.upTo))*1000,f=1-(b.up-t)/tot;bar(c,cx,cy-a.ay+16,46,f,'#ffd23f');c.fillStyle='#fff';c.strokeStyle='#2b1246';c.lineWidth=3;c.font='bold 13px sans-serif';c.textAlign='center';const s=(b.cons?'🔨 ':'⬆ ')+fmtT((b.up-t)/1000);c.strokeText(s,cx,cy-a.ay+12);c.fillText(s,cx,cy-a.ay+12)}
  else if(collectible(b)>=8){const bob=Math.sin(t/260+b.id)*4,top=cy-a.ay+(w>2?46:30);const g=b.acc.gold>=1,ch=b.acc.chek>=1;c.save();c.translate(cx,top+bob);rrect(c,-17,-17,34,34,10,'#fff');c.font='20px sans-serif';c.textAlign='center';c.fillText(g&&(!ch||b.t=='gold_mine')?'🪙':'🍼',0,7);c.restore()}}
 else if(sc.mode=='battle'&&!dead&&b.hp<b.mx&&!TRAPS.includes(b.t)){bar(c,cx,cy-a.ay+(w>2?40:26),Math.min(60,20+w*12),b.hp/b.mx,'#7dff6a')}}
function rrect(c,x,y,w,h,r,f){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=f;c.fill();c.lineWidth=2.5;c.strokeStyle='#2b1246';c.stroke()}
function drawUnit(c,u,sc){const[x,y]=gIso(u.x,u.y),im=IM['u'+u.i];if(!im||!im.complete||!im.naturalWidth)return;const h=u.sz*1.7,w=h*im.naturalWidth/im.naturalHeight,bob=u.mv?-Math.abs(Math.sin(u.t*10))*3:0;
 c.fillStyle='rgba(0,0,0,.28)';c.beginPath();c.ellipse(x,y,w*.38,w*.17,0,0,7);c.fill();const lift=u.fly?18:0;
 c.save();c.translate(x,y+bob-lift);if(u.hid)c.globalAlpha=.4;if(u.s==1){c.filter='hue-rotate(0deg)'}
 c.scale(u.face*(u.i==9?1:1),1);c.drawImage(im,-w/2,-h+4,w,h);
 if(u.flash>0){c.globalAlpha=.5;c.globalCompositeOperation='lighter';c.drawImage(im,-w/2,-h+4,w,h)}c.restore();
 if(u.hp<u.mx)bar(c,x,y-h-4-lift,24,u.hp/u.mx,u.s?'#ff5a5a':'#7dff6a');
 if(u.s==1){c.fillStyle='#ff4040';c.fillRect(x-3,y-h-12-lift,6,4)}
 if(u.st>0||u.slow>0||u.fire>0){c.font='14px sans-serif';c.textAlign='center';c.fillText(u.st>0?'💫':u.fire>0?'🔥':'❄',x,y-h-14-lift)}}
function drawProj(c,p){const k=Math.min(1,p.t/p.d),x=p.x0+(p.x1-p.x0)*k,y=p.y0+(p.y1-p.y0)*k,[sx,sy]=gIso(x,y),arc=Math.sin(Math.PI*k)*(p.k=='cannon'||p.k=='meme_factory'?40:p.k=='u'?12:6),z=24+(p.side==1?0:14);
 c.save();c.translate(sx,sy-z-arc);
 if(p.k=='cannon'){c.fillStyle='#222';c.beginPath();c.arc(0,0,6,0,7);c.fill();c.strokeStyle='#fff6';c.stroke()}
 else if(p.k=='mel_tower'){c.strokeStyle='#ffe46a';c.lineWidth=3;c.beginPath();c.moveTo(0,0);c.lineTo(-8,5);c.stroke()}
 else if(p.k=='meme_factory'){c.fillStyle='#fff';c.strokeStyle='#111';c.lineWidth=2;c.beginPath();c.arc(0,0,8,0,7);c.fill();c.stroke();c.fillStyle='#111';c.fillRect(-4,-3,2,2);c.fillRect(2,-3,2,2);c.fillRect(-4,2,8,1.5)}
 else if(p.k=='mod_tower'){c.strokeStyle='#ff3b3b';c.lineWidth=3;c.beginPath();c.arc(0,0,6,0,7);c.stroke()}
 else{c.fillStyle='#fff3a0';c.strokeStyle='#2b1246';c.lineWidth=1.5;c.beginPath();c.arc(0,0,4,0,7);c.fill();c.stroke()}
 c.restore()}
function drawFx(c,f){const[x,y]=gIso(f.x,f.y),k=1-f.l/f.m;c.save();
 if(f.k=='n'){c.globalAlpha=Math.min(1,f.l*2.2);c.font='bold 15px sans-serif';c.textAlign='center';c.lineWidth=3;c.strokeStyle='#2b1246';c.fillStyle=f.c;const yy=y-34-k*30;c.strokeText(f.t,x,yy);c.fillText(f.t,x,yy)}
 else if(f.k=='r'){c.globalAlpha=1-k;c.strokeStyle=f.c;c.lineWidth=4*(1-k)+1;c.beginPath();c.ellipse(x,y,10+k*44,5+k*22,0,0,7);c.stroke()}
 else if(f.k=='p'){c.globalAlpha=Math.min(1,f.l*2.5);c.fillStyle=f.c;c.beginPath();c.arc(x,y-f.z*14-10,3,0,7);c.fill()}
 c.restore()}
function sortKey(o){return o.cx!=null&&o.w?o.cx+o.cy:(o.t!==undefined&&o.x!==undefined&&bw(o)?o.x+o.y+bw(o):o.x+o.y)}
// sc: {mode,bld,units,proj,fx,t,sel,ghost,grid,red,shake,scout}
function render(sc){const c=ctx;c.setTransform(DPR,0,0,DPR,0,0);c.fillStyle='#1a0f33';c.fillRect(0,0,VW,VH);
 c.save();c.translate(VW/2,VH/2);c.scale(cam.z,cam.z);c.translate(-cam.x,-cam.y);if(sc.shake>.5)c.translate((Math.random()-.5)*sc.shake,(Math.random()-.5)*sc.shake);
 c.drawImage(ground,-GX0,-10);
 if(sc.grid)drawGrid(c);
 if(sc.red){c.beginPath();for(let i=0;i<GN;i++)for(let j=0;j<GN;j++)if(sc.red[i*GN+j]){const p=[gIso(i,j),gIso(i+1,j),gIso(i+1,j+1),gIso(i,j+1)];p.forEach((q,k)=>k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.closePath()}c.fillStyle='rgba(255,60,60,.22)';c.fill()}
 if(sc.sel&&sc.mode=='base'){const b=sc.sel;drawDia(c,b.x,b.y,bw(b),'rgba(255,255,255,.28)','#fff',3)}
 if(sc.ghost){const g=sc.ghost;drawDia(c,g.x,g.y,BD[g.t].w,g.ok?'rgba(80,255,80,.4)':'rgba(255,60,60,.45)',g.ok?'#aff':'#f88',3)}
 const items=[];for(const b of sc.bld)if(!(sc.ghost&&sc.ghost.id===b.id)||sc.ghost.fresh)items.push([b.x+b.y+bw(b)+(b.t=='wall'?-.01:0),0,b]);
 if(sc.units)for(const u of sc.units)items.push([u.x+u.y,1,u]);
 items.sort((a,b)=>a[0]-b[0]);
 for(const[,k,o]of items){if(k==0)drawBld(c,o,sc);else drawUnit(c,o,sc)}
 if(sc.ghost){const g=sc.ghost,a=getArt(g.t,1,g.flip,1),[x,y]=gIso(g.x+BD[g.t].w/2,g.y+BD[g.t].w/2);c.globalAlpha=.8;c.drawImage(a.c,x-a.ax,y-a.ay,a.w,a.h);c.globalAlpha=1}
 if(sc.proj)for(const p of sc.proj)drawProj(c,p);
 if(sc.fx)for(const f of sc.fx)drawFx(c,f);
 c.restore()}
