// game.js — главный цикл, ввод (касания/мышь), режимы: база, строительство, бой
const UIA={};let mode='base',P=null,BS=null,shopView=null,armyView=null;
// ---------- HUD ----------
const disp={gold:-1,chek:-1,cups:-1,lv:-1};
function setPill(id,k,v,cap){const el=$('#v'+id);const old=disp[k];if(Math.round(v)!==old){el.textContent=fmt(v);if(old>=0){const p=el.closest('.pill');const c=v>old?'up':'dn';p.classList.remove('up','dn');void p.offsetWidth;p.classList.add(c)}disp[k]=Math.round(v)}if(cap)$('#c'+id).style.width=Math.min(100,v/cap*100)+'%'}
function updateHud(){setPill('g','gold',S.gold,capOf('gold'));setPill('c','chek',S.chek,capOf('chek'));setPill('k','cups',S.cups);setPill('l','lv',playerLevel())}
function flyIcon(em,x,y,target){const i=document.createElement('i');i.textContent=em;i.style.left=x+'px';i.style.top=y+'px';$('#fly').appendChild(i);const r=$(target).getBoundingClientRect();void i.offsetWidth;i.style.transform=`translate(${r.left+20-x}px,${r.top+16-y}px) scale(.5)`;i.style.opacity='.4';setTimeout(()=>i.remove(),800)}
// ---------- сцена ----------
function centerOn(gx,gy,z){const[x,y]=gIso(gx,gy);cam.x=x;cam.y=y;if(z)cam.z=z;clampCam()}
function baseScene(){return{mode:'base',bld:S.bld.filter(placed),sel:mode=='base'&&!P?selB:null,ghost:P,grid:!!P,t:0}}
function computeRed(B){const r=new Uint8Array(GN*GN);for(const b of B.bld){if(b.dead||isDeco(b.t)||TRAPS.includes(b.t))continue;for(let i=b.x-2;i<b.x+b.w+2;i++)for(let j=b.y-2;j<b.y+b.w+2;j++)if(i>=0&&j>=0&&i<GN&&j<GN)r[i*GN+j]=1}return r}
function battleScene(){const B=BS.B;if(BS.sel!=null&&!B.scout&&BS.redKey!==B.dead){BS.red=computeRed(B);BS.redKey=B.dead}
 return{mode:'battle',bld:B.bld,units:B.units,proj:B.proj,fx:B.fx,t:B.t,shake:B.shake,red:BS.sel!=null&&!B.scout?BS.red:null,scout:B.scout}}
// ---------- строительство ----------
function spotNear(t,gx,gy){const w=BD[t].w,occ=occGrid(P&&P.id||0);let best=null,bd=1e9;for(let x=PAD;x<=GN-PAD-w;x++)for(let y=PAD;y<=GN-PAD-w;y++){if(!canPlaceAt(t,x,y,0,occ))continue;const d=Math.hypot(x+w/2-gx,y+w/2-gy);if(d<bd){bd=d;best=[x,y]}}return best||[PAD,PAD]}
function startPlace(t,id,keep){showSel(null);const c=screenToGrid(VW/2,VH*.45);const b=id?S.bld.find(b=>b.id==id):null;let x,y;
 if(keep){x=keep[0];y=keep[1]}else if(b&&!b.stored){x=b.x;y=b.y}else{[x,y]=spotNear(t,c[0],c[1])}
 P={t,id:id||0,x,y,flip:b?b.flip:0,fresh:!id};updGhost();$('#bctl').classList.add('on');$('#bar').style.display='none'}
function updGhost(){if(!P)return;P.ok=canPlaceAt(P.t,P.x,P.y,P.id||0)}
function endPlace(){P=null;$('#bctl').classList.remove('on');$('#bar').style.display='flex'}
$('#bno').onclick=()=>{snd('click');endPlace()};
$('#bflip').onclick=()=>{snd('click');if(P)P.flip=P.flip?0:1};
$('#bok').onclick=()=>{if(!P||!P.ok){snd('error');toast('Здесь нельзя строить');return}
 if(P.fresh){const t=P.t,r=placeBuilding(t,P.x,P.y,P.flip);if(r){toast(r);snd('error');return}const[sx,sy]=gridToScreen(P.x+BD[t].w/2,P.y+BD[t].w/2);flyIcon('🪙',$('#pg').getBoundingClientRect().left+30,60,'#bctl');
  const more=(t=='wall'||isDeco(t))&&!reasonCantBuild(t);if(more){const nx=[P.x+1,P.y],ok=canPlaceAt(t,nx[0],nx[1]);startPlace(t,0,ok?nx:null)}else endPlace()}
 else{const b=S.bld.find(b=>b.id==P.id);b.x=P.x;b.y=P.y;b.flip=P.flip;b.stored=0;snd('build');saveGame();endPlace()}updateHud()};
// ---------- сбор ----------
function doCollect(b){const got=collect(b);if(!Object.keys(got).length){toast('Хранилище заполнено! Улучши Резиденцию или построй хранилище.');snd('error');return false}
 const[sx,sy]=gridToScreen(b.x+bw(b)/2,b.y+bw(b)/2);snd('collect');if(got.gold)flyIcon('🪙',sx,sy-50,'#pg');if(got.chek)flyIcon('🍼',sx+14,sy-50,'#pc');return true}
// ---------- ввод ----------
const ptrs=new Map();let tap=null,dragG=null,pinch=0;
function bldAtGrid(gx,gy){const hit=(x,y)=>S.bld.find(b=>placed(b)&&x>=b.x&&x<b.x+bw(b)&&y>=b.y&&y<b.y+bw(b));let b=hit(Math.floor(gx),Math.floor(gy));
 if(!b)for(const k of[1,2,3]){b=hit(Math.floor(gx-k*.55),Math.floor(gy-k*.55));if(b)break}return b}
function onTap(px,py){const[gx,gy]=screenToGrid(px,py);
 if(mode=='battle'){if(!BS||BS.B.over||BS.B.scout||BS.def||BS.sel==null)return;const B=BS.B;if(!B.army[BS.sel])return;const i=Math.floor(gx),j=Math.floor(gy);
  if(gx<.3||gy<.3||gx>GN-.3||gy>GN-.3)return;if(!BS.red||BS.redKey!==B.dead){BS.red=computeRed(B);BS.redKey=B.dead}
  if(BS.red[i*GN+j]){if(performance.now()-(BS.warn||0)>2500){toast('Слишком близко к зданиям — выбери место подальше');BS.warn=performance.now()}snd('error');return}
  deployUnit(B,BS.sel,gx,gy);buildUnitBar();return}
 if(P){const w=BD[P.t].w;P.x=Math.round(gx-w/2);P.y=Math.round(gy-w/2);updGhost();snd('click');return}
 // пузырь сбора
 const wx=(px-VW/2)/cam.z+cam.x,wy=(py-VH/2)/cam.z+cam.y;
 for(const b of S.bld){if(b.bub&&collectible(b)>=8&&Math.abs(wx-b.bub[0])<24&&Math.abs(wy-b.bub[1])<24){doCollect(b);return}}
 const b=bldAtGrid(gx,gy);if(b){if(collectible(b)>=8&&doCollect(b)){showSel(null);return}snd('click');showSel(b)}else showSel(null)}
cvs=$('#cv');ctx=cvs.getContext('2d');
cvs.addEventListener('pointerdown',e=>{cvs.setPointerCapture(e.pointerId);ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(ptrs.size==1){tap={x:e.clientX,y:e.clientY,t:performance.now(),mv:0};dragG=null;if(P){const g=screenToGrid(e.clientX,e.clientY),w=BD[P.t].w;if(g[0]>=P.x-.5&&g[0]<P.x+w+.5&&g[1]>=P.y-.5&&g[1]<P.y+w+.5)dragG=[g[0]-P.x,g[1]-P.y]}}
 else{tap=null;dragG=null;const a=[...ptrs.values()];pinch=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}});
cvs.addEventListener('pointermove',e=>{const p=ptrs.get(e.pointerId);if(!p)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
 if(ptrs.size==2){const a=[...ptrs.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(pinch>0){zoomAt((a[0].x+a[1].x)/2,(a[0].y+a[1].y)/2,d/pinch)}pinch=d;return}
 if(tap){tap.mv+=Math.abs(dx)+Math.abs(dy);if(tap.mv<9&&!dragG)return}
 if(dragG&&P){const g=screenToGrid(e.clientX,e.clientY);P.x=Math.round(g[0]-dragG[0]);P.y=Math.round(g[1]-dragG[1]);updGhost();return}
 cam.x-=dx/cam.z;cam.y-=dy/cam.z;clampCam()});
const upH=e=>{const wasTap=tap&&tap.mv<9&&performance.now()-tap.t<600&&!dragG;ptrs.delete(e.pointerId);if(ptrs.size<2)pinch=0;if(wasTap&&e.type=='pointerup')onTap(tap.x,tap.y);if(ptrs.size==0){tap=null;dragG=null}};
cvs.addEventListener('pointerup',upH);cvs.addEventListener('pointercancel',upH);
function zoomAt(px,py,k){const wx=(px-VW/2)/cam.z+cam.x,wy=(py-VH/2)/cam.z+cam.y;cam.z=Math.max(cam.min,Math.min(cam.max,cam.z*k));cam.x=wx-(px-VW/2)/cam.z;cam.y=wy-(py-VH/2)/cam.z;clampCam()}
cvs.addEventListener('wheel',e=>{e.preventDefault();zoomAt(e.clientX,e.clientY,e.deltaY<0?1.12:.89)},{passive:false});
// ---------- кнопки ----------
document.querySelectorAll('#bar button').forEach(b=>b.onclick=()=>{snd('click');const f={shop:UIA.winShop,army:UIA.winArmy,atk:UIA.winAtk,lab:UIA.winLab,info:UIA.winInfo}[b.dataset.a];f()});
$('#bset').onclick=()=>{snd('click');openWin('Настройки',settingsHtml)};
$('#sel').addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el||el.disabled)return;snd('click');UIA[el.dataset.a]&&UIA[el.dataset.a](el.dataset.v)});
Object.assign(UIA,{
 winShop(){shopView=null;shopTab='main';openWin('Магазин',()=>shopView?shopItemHtml(shopView):shopHtml())},
 shopTab(v){shopTab=v;shopView=null;renderWin()},shopItem(v){shopView=v;renderWin()},shopBack(){shopView=null;renderWin()},
 shopBuild(v){closeWin();startPlace(v)},placeStored(v){const b=S.bld.find(b=>b.id==+v);closeWin();startPlace(b.t,b.id)},
 winArmy(){armyView=null;armyTab='train';openWin('Армия',()=>armyView!==null?unitInfoHtml(armyView):armyHtml());curWin.live=()=>{if(armyView===null&&armyTab=='train'&&$('#qb')){$('#qb').innerHTML=qHtml();$('#capb').innerHTML=capHtml()}else if(armyView!==null)renderWin()}},
 armyTab(v){armyTab=v;armyView=null;renderWin()},train(v){const r=enqueue(+v);if(r){toast(r);snd('error')}else{$('#qb').innerHTML=qHtml();$('#capb').innerHTML=capHtml();updateHud()}},
 cancelQ(v){cancelQueue(+v);renderWin();updateHud()},unitInfo(v){armyView=+v;renderWin()},armyBack(){armyView=null;renderWin()},
 research(v){const r=startResearch(+v);if(r){toast(r);snd('error')}else{toast('Исследование началось');updateHud()}renderWin()},
 winLab(){showSel(null);armyView=null;openWin('Лаборатория мемов',()=>armyView!==null?unitInfoHtml(armyView):labHtml());curWin.live=()=>{if(armyView===null)renderWin()}},
 winInfo(){openWin('Моя база',infoHtml)},
 winAtk(){curBase=curBase||pickBase();openWin('Поиск соперника',atkHtml)},
 nextBase(){if(S.gold<40)return;pay(40);curBase=pickBase(curBase.id);updateHud();renderWin()},
 scout(){closeWin();startBattle(curBase,true)},attack(){closeWin();startBattle(curBase,false)},
 arena(){const a=S.bld.find(b=>b.t=='hype_arena'&&active(b));if(!a){toast('Нужна Арена хайпа');return}if(S.chek<100){toast('Нужно 100 чекушек для входа');return}pay(0,100);closeWin();showSel(null);startBattle(Object.assign({},ARENA_BASE),false)},
 defTest(){closeWin();startDefense()},mute(){mute=!mute;S.opts.mute=mute?1:0;renderWin()},saveNow(){saveGame();toast('Сохранено')},
 reset(){if(UIA._rc){resetGame();location.reload()}else{UIA._rc=1;toast('Нажми ещё раз — прогресс будет стёрт');setTimeout(()=>UIA._rc=0,3000)}},
 home(){closeWin()},again(){const f=()=>{curBase=pickBase(curBase&&curBase.id);UIA.winAtk()};closeWin();setTimeout(f,60)},
 upgrade(){const r=startUpgrade(selB);if(r){toast(r);snd('error')}showSel(selB);updateHud()},selClose(){showSel(null)},
 moveB(){const b=selB;startPlace(b.t,b.id)},storeB(){const b=selB;showSel(null);removeToStorage(b);toast(BD[b.t].n+' — на склад')}});
window.onBuilt=b=>{snd('upgrade');if(selB===b)showSel(b);const[sx,sy]=gridToScreen(b.x+bw(b)/2,b.y+bw(b)/2);fxLevel(sx,sy)};
function fxLevel(x,y){const i=document.createElement('i');i.textContent='✨';i.style.cssText=`position:fixed;left:${x}px;top:${y-40}px;font-size:34px;z-index:25;pointer-events:none;transition:transform .8s,opacity .8s`;document.body.appendChild(i);void i.offsetWidth;i.style.transform='translateY(-40px) scale(1.6)';i.style.opacity='0';setTimeout(()=>i.remove(),900)}
// ---------- бой ----------
function setBattleUI(on){['#hud','#bar'].forEach(s=>$(s).style.display=on?'none':(s=='#hud'?'flex':'flex'));$('#bhud').classList.toggle('on',on);if(on)showSel(null)}
function startBattle(base,scout){const B=newBattle(base,'attack',scout);B.army=scout?{}:Object.assign({},S.army);BS={B,sel:null,red:null,redKey:-1,def:false,ended:0,scout};mode='battle';endPlace();setBattleUI(true);
 const rc=B.res?[B.res.cx,B.res.cy]:[20,20];centerOn(rc[0],rc[1],Math.max(cam.min,.55));$('#bend').textContent=scout?'✕':'🏳';buildUnitBar();
 const first=Object.keys(B.army).filter(i=>B.army[i]>0)[0];BS.sel=first!=null?+first:null;buildUnitBar()}
function startDefense(){const B=newBattle(battleFromState(),'defense');B.script=raidScript();BS={B,sel:null,red:null,redKey:-1,def:true,ended:0};mode='battle';endPlace();setBattleUI(true);centerOn(20,20,.6);$('#bend').textContent='✕';buildUnitBar()}
function buildUnitBar(){const B=BS.B,el=$('#bunits');
 if(BS.scout){el.innerHTML='<button class="no" id="sa" style="flex:1">⚔ Напасть!</button><button id="sb" style="flex:1">← Назад</button>';$('#sa').onclick=()=>{const b=BS.B.base;exitBattle();startBattle(b,false)};$('#sb').onclick=()=>exitBattle();$('#bhint').textContent='Разведка: ловушки показаны полупрозрачными';return}
 if(BS.def){el.innerHTML='';$('#bhint').textContent='Учебный набег на твою базу — смотри, как держится оборона';return}
 const ids=Object.keys(B.army).map(Number).filter(i=>B.army[i]>0);if(BS.sel==null||!B.army[BS.sel])BS.sel=ids[0]??null;
 el.innerHTML=ids.map(i=>`<div class="card ${BS.sel===i?'on':''}" data-i="${i}"><span class="cn">×${B.army[i]}</span><img src="${uimg(i)}"><b>${UC[i][0]}</b></div>`).join('')||'<div style="padding:14px;font-weight:900">Все бойцы выставлены</div>';
 el.querySelectorAll('.card').forEach(c=>c.onclick=()=>{BS.sel=+c.dataset.i;snd('click');buildUnitBar()});
 $('#bhint').textContent=B.started?'':ids.length?'Выбери бойца и тапай по карте — подальше от зданий':''}
let endConf=0,endTm;$('#bend').onclick=()=>{if(!BS)return;const B=BS.B;snd('click');if(BS.scout||BS.def||!B.started||B.over){exitBattle();return}
 if(endConf){endConf=0;clearTimeout(endTm);$('#bend').textContent='🏳';endBattle(B,'surrender')}else{endConf=1;$('#bend').textContent='Сдаться?';$('#bend').style.width='auto';endTm=setTimeout(()=>{endConf=0;if($('#bend'))$('#bend').textContent='🏳';$('#bend').style.width=''},2500)}};
function exitBattle(){BS=null;mode='base';setBattleUI(false);$('#bend').style.width='';endConf=0;const r=S.bld.find(b=>b.t=='residence');centerOn(r.x+2,r.y+2,.8);updateHud();saveGame()}
function finishBattle(){const B=BS.B,base=B.base;let extra=null;
 if(BS.def){const win=B.pct<50;if(win){S.stats.defs++;addRes('chek',60);snd('win')}else snd('lose');extra={def:1,title:win?'Набег отбит!':'Оборону прорвали',rows:`<tr><td>Итог</td><td>${win?'Оборона держится (+60 🍼)':'Укрепи оборону!'}</td></tr>`}}
 else{if(B.dep>0){S.stats.att++;for(const k in S.army)S.army[k]=B.army[k]||0;for(const k in B.army)S.army[k]=B.army[k];
   B.gold=addRes('gold',B.gold);B.chek=addRes('chek',B.chek);S.cups=Math.max(0,S.cups+B.cups);S.stats.stars+=B.stars;S.stats.looted+=B.gold+B.chek;S.stats.maxStars=Math.max(S.stats.maxStars||0,B.stars);if(B.stars>0)S.stats.wins++;
   const prev=S.camp[base.id]||0;if(B.stars>prev){const bonus=(B.stars-prev)*80;S.camp[base.id]=B.stars;addRes('gold',bonus);extra={rows:`<tr><td>Бонус кампании</td><td>🪙 +${bonus}</td></tr>`}}
   addXp(8+B.stars*10);B.stars>0?snd('win'):snd('lose')}}
 checkAch();saveGame();updateHud();openWin('Итоги боя',()=>resultHtml(B,extra),()=>exitBattle())}
// ---------- главный цикл ----------
let last=performance.now(),ecoAcc=0,acc=0,achT=0;
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.1,(now-last)/1000);last=now;
 if(mode=='battle'&&BS){const B=BS.B;acc+=dt;let n=0;while(acc>=BT&&n<5){stepBattle(B,BT);acc-=BT;n++}if(acc>BT*5)acc=0;
  $('#btime').textContent=B.started||B.script?fmtT(Math.max(0,BATTLE_TIME-B.clock)):'3:00';$('#bpct').textContent=B.pct+'%';[...$('#bstars').children].forEach((s,i)=>s.classList.toggle('on',i<B.stars));
  if(B.over&&!BS.ended){BS.ended=1;setTimeout(()=>{if(BS&&BS.B===B&&curWin==null)finishBattle()},B.pct>=100?1400:700)}
  render(battleScene())}
 else{ecoAcc+=dt;if(ecoAcc>=.5){tickEconomy(ecoAcc);tickQueue(ecoAcc);ecoAcc=0;finishTimers();achT+=.5;if(achT>=3){achT=0;checkAch()}}
  for(const b of S.bld){if(!placed(b))continue;const a=getArt(b.t,b.l,b.flip,1),w=bw(b),[cx,cy]=gIso(b.x+w/2,b.y+w/2);b.bub=[cx,cy-a.ay+(w>2?46:30)]}
  render(baseScene());updateHud()
  if(selB&&$('#sel').classList.contains('on')&&((now|0)%5==0))showSel(selB)}}
// ---------- запуск ----------
function boot(){resize();addEventListener('resize',()=>{resize();clampCam()});buildGround();const had=loadGame();VOL=S.opts.vol??.8;mute=!!S.opts.mute;
 const off=applyOffline();const r=S.bld.find(b=>b.t=='residence');centerOn(r.x+2,r.y+2,Math.max(.7,cam.min));updateHud();startAutosave();
 if(had&&off>120){const s=S.bld.reduce((a,b)=>a+collectible(b),0);if(s>20)setTimeout(()=>toast('Пока тебя не было, накопилось: '+fmt(s)+' ресурсов. Собери их!'),600)}
 else if(!had)setTimeout(()=>toast('Добро пожаловать! Нажми на шахту или фабрику, чтобы собрать ресурсы'),700);
 requestAnimationFrame(loop)}
$('#play').onclick=()=>{au();snd('ready');$('#splash').classList.add('off');setTimeout(()=>$('#splash').remove(),600)};
boot();
window.__dbg={get S(){return S},get BS(){return BS},get P(){return P},UIA,startBattle,startPlace,cam,get mode(){return mode}};
