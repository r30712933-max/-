// combat.js — боевая система: здания обороны, снаряды, урон, итоги. Бойцов ведёт ai.js.
const BT=1/30,BATTLE_TIME=180;
let UID=1;
function mkBB(t,x,y,l,id){const w=BD[t].w,hp=bHp(t,l);return{id,t,x,y,l,w,cx:x+w/2,cy:y+w/2,hp,mx:hp,dead:0,cd:Math.random()*1.2,st:0,bl:0,deb:0,burn:0,slow:0}}
function newBattle(base,mode,scout){const B={base,mode:mode||'attack',scout:!!scout,bld:[],units:[],proj:[],fx:[],t:0,clock:0,started:0,over:0,occ:new Int32Array(GN*GN),army:{},dep:0,lost:0,pct:0,stars:0,dead:0,tot:0,resKilled:0,shake:0,script:null,sch:0};
 let n=1;for(const e of base.layout){const b=mkBB(e[0],e[1],e[2],e[3]||1,n++);b.i=B.bld.length;B.bld.push(b)}
 for(const b of B.bld){if(countsAsTarget(b.t))B.tot++;if(b.t=='residence')B.res=b;if(!TRAPS.includes(b.t)&&!isDeco(b.t))for(let i=0;i<b.w;i++)for(let j=0;j<b.w;j++)B.occ[(b.x+i)*GN+b.y+j]=b.i+1}
 for(const gd of (base.guards||[])){const c=B.res?B.res.cx:20,cy=B.res?B.res.cy:20;for(let k=0;k<gd[1];k++)spawnUnit(B,gd[0],c+Math.cos(k*2.1)*2.8+1,cy+Math.sin(k*2.1)*2.8+1,1,gd[2]||1,true)}
 return B}
function battleFromState(){const layout=S.bld.filter(b=>active(b)).map(b=>[b.t,b.x,b.y,b.l]);
 const base={name:'Твоя база',layout,guards:[],gold:0,chek:0,cups:0};const ch=S.bld.find(b=>b.t=='chek_house'&&active(b));if(ch)base.guards.push([1,2+ch.l]);return base}
function spawnUnit(B,i,x,y,side,lv,home){const st=uStat(i,lv||1),out=[];const n=st.cnt;
 for(let k=0;k<n;k++){const a=k*2.4;const u={id:UID++,i,s:side,x:x+(n>1?Math.cos(a)*.4:0),y:y+(n>1?Math.sin(a)*.4:0),hp:st.hp,mx:st.hp,dmg:st.dmg,rng:st.rng,ranged:st.ranged,sp:st.sp,cd:st.cd,ac:Math.random()*.3,sz:st.sz,fl:st.fl,hunt:st.hunt,fly:st.fly,
  tg:null,tk:'',rt:0,st:0,slow:0,wet:0,haste:0,hid:st.fl=='p'?1:0,face:1,mv:0,run:0,stk:0,fb:null,fbt:0,t:0,gt:0,lt:0,ft:0,home:home?[x,y]:null,fire:0,lv:lv||1,flash:0,fear:0};
  B.units.push(u);out.push(u)}return out}
function deployUnit(B,i,x,y){const l=unitLvl(i);B.army[i]--;B.dep++;if(!B.started){B.started=1}
 if(UC[i][9]=='x'){for(let k=0;k<6;k++){const a=k*1.05;spawnUnit(B,20,x+Math.cos(a)*.7,y+Math.sin(a)*.7,0,l)}fxRing(B,x,y,'#ffd23f');snd('pop');return}
 spawnUnit(B,i,x,y,0,l);fxRing(B,x,y,'#fff');snd('deploy')}
// ---- эффекты ----
const fxNum=(B,x,y,t,c)=>{if(B.fx.length<140)B.fx.push({k:'n',x,y,t,l:.8,m:.8,c:c||'#fff'})};
const fxRing=(B,x,y,c)=>{B.fx.push({k:'r',x,y,l:.4,m:.4,c:c||'#fff'})};
function burst(B,x,y,col,n,sp){for(let i=0;i<n&&B.fx.length<220;i++){const a=Math.random()*6.283,v=(sp||3)*(.4+Math.random());B.fx.push({k:'p',x,y,vx:Math.cos(a)*v*.5,vy:Math.sin(a)*v*.5,z:.2,vz:2+Math.random()*3,l:.5+Math.random()*.4,m:.9,c:col})}}
// ---- урон ----
function dmgBuilding(B,b,d,src){if(b.dead)return;b.hp-=d;b.flash=.12;if(d>=1)fxNum(B,b.cx,b.cy,Math.round(d),'#ffe9a0');if(b.hp<=0)killBuilding(B,b,src)}
function killBuilding(B,b,src){if(b.dead)return;b.dead=1;b.hp=0;b.t0=B.t;for(let i=0;i<b.w;i++)for(let j=0;j<b.w;j++)if(B.occ[(b.x+i)*GN+b.y+j]==b.i+1)B.occ[(b.x+i)*GN+b.y+j]=0;
 burst(B,b.cx,b.cy,'#a89878',14+b.w*4,3);burst(B,b.cx,b.cy,'#ffd23f',8,2.5);B.shake=Math.max(B.shake,b.w>2?10:5);snd('boom');
 if(countsAsTarget(b.t)){B.dead++;B.pct=Math.floor(B.dead/B.tot*100)}if(b.t=='residence')B.resKilled=1;B.stars=(B.pct>=50?1:0)+(B.resKilled?1:0)+(B.pct>=100?1:0)}
function dmgUnit(B,u,d,src){if(u.hp<=0)return;if(u.wet>0)d*=1.3;u.hp-=d;u.flash=.1;fxNum(B,u.x,u.y,Math.round(d),u.s?'#fff':'#ff9a9a');if(u.hp<=0)killUnit(B,u)}
function killUnit(B,u){u.hp=0;u.dead=1;burst(B,u.x,u.y,'#fff',6,2);if(u.s==0)B.lost++;
 if(u.fl=='z'){for(const o of B.units)if(o.s!=u.s&&o.hp>0&&Math.hypot(o.x-u.x,o.y-u.y)<1.6)dmgUnit(B,o,70,u);for(const b of B.bld)if(!b.dead&&Math.hypot(b.cx-u.x,b.cy-u.y)<1.8+b.w/2)dmgBuilding(B,b,40,u);fxRing(B,u.x,u.y,'#9fd6ff');burst(B,u.x,u.y,'#fff',18,3);snd('pop')}}
function splashAt(B,x,y,r,d,side,bldF){for(const o of B.units)if(o.s!=side&&o.hp>0&&Math.hypot(o.x-x,o.y-y)<r)dmgUnit(B,o,d);
 if(bldF)for(const b of B.bld)if(!b.dead&&!isDeco(b.t)&&!TRAPS.includes(b.t)&&distRect(b,x,y)<r)dmgBuilding(B,b,d*bldF)}
const distRect=(b,x,y)=>Math.hypot(Math.max(b.x-x,0,x-(b.x+b.w)),Math.max(b.y-y,0,y-(b.y+b.w)));
// ---- оборона ----
function stepDefense(B,b,dt){if(b.dead)return;if(b.burn>0){b.burn-=dt;b.hp-=7*dt;if(b.hp<=0)killBuilding(B,b)}if(b.flash>0)b.flash-=dt;
 if(b.bl>0)b.bl-=dt;if(b.st>0)b.st-=dt;if(b.deb>0)b.deb-=dt;if(b.slow>0)b.slow-=dt;
 if(TRAPS.includes(b.t)){const ds=dStat(b.t,b.l);for(const u of B.units)if(u.s==0&&u.hp>0&&!u.fly&&Math.hypot(u.x-b.cx,u.y-b.cy)<ds.rng){trigTrap(B,b,ds);break}return}
 if(!DEF_TYPES.includes(b.t)||B.over)return;const ds=dStat(b.t,b.l);b.cd-=dt;if(b.cd>0||b.bl>0||b.st>0)return;
 let best=null,bd=1e9;for(const u of B.units){if(u.s!=0||u.hp<=0||u.hid||(u.fly&&!ds.air))continue;const d=Math.hypot(u.x-b.cx,u.y-b.cy);if(d<=ds.rng&&d<bd){bd=d;best=u}}
 if(!best)return;b.cd=ds.rate*(b.slow>0?1.5:1);const dm=ds.dmg*(b.deb>0?.7:1);
 B.proj.push({x0:b.cx,y0:b.cy,x1:best.x,y1:best.y,tg:best,t:0,d:Math.max(.12,bd/(b.t=='cannon'?13:b.t=='mel_tower'?20:11)),k:b.t,dmg:dm,ds,side:1});snd(b.t=='cannon'?'cannon':'shoot')}
function trigTrap(B,b,ds){b.dead=1;b.hp=0;b.t0=B.t;for(const u of B.units)if(u.s==0&&u.hp>0&&!u.fly&&Math.hypot(u.x-b.cx,u.y-b.cy)<ds.spl){dmgUnit(B,u,ds.dmg);if(ds.stun)u.st=ds.stun}
 fxRing(B,b.cx,b.cy,'#ff5050');burst(B,b.cx,b.cy,ds.stun?'#5ae0ff':'#ff5a3c',18,4);B.shake=Math.max(B.shake,6);snd('boom')}
function stepProj(B,dt){for(const p of B.proj){p.t+=dt;if(p.t<p.d)continue;p.done=1;
  if(p.side==1){const tg=p.tg;if(p.k=='meme_factory'){const x=tg.hp>0?tg.x:p.x1,y=tg.hp>0?tg.y:p.y1;splashAt(B,x,y,p.ds.spl,p.dmg,1,0);fxRing(B,x,y,'#fff');burst(B,x,y,'#fff',8,2.5)}
   else if(tg.hp>0){dmgUnit(B,tg,p.dmg);if(p.k=='mod_tower'){tg.st=p.ds.ban;fxNum(B,tg.x,tg.y-.6,'БАН!','#ff4040');snd('ban')}else snd('hit')}}
  else{const tg=p.tg;if(p.splash){splashAt(B,p.x1,p.y1,p.splash,p.dmg,0,.5)}if(tg&&!tg.dead&&tg.hp>0){if(p.tk=='b')dmgBuilding(B,tg,p.dmg,p.u);else dmgUnit(B,tg,p.dmg,p.u)}}}
 B.proj=B.proj.filter(p=>!p.done)}
function stepFx(B,dt){for(const f of B.fx){f.l-=dt;if(f.k=='p'){f.x+=f.vx*dt;f.y+=f.vy*dt;f.z+=f.vz*dt;f.vz-=9*dt;if(f.z<0){f.z=0;f.vz*=-.3}}}B.fx=B.fx.filter(f=>f.l>0)}
// ---- главный шаг ----
function stepBattle(B,dt){if(B.over)return;
 if(B.started)B.clock+=dt;B.t+=dt;if(B.shake>0)B.shake*=.9;
 if(B.script){while(B.sch<B.script.length&&B.t>=B.script[B.sch].t){const e=B.script[B.sch++];B.deployed=(B.deployed||0)+1;spawnUnit(B,e.u,e.x,e.y,0,e.l||1);fxRing(B,e.x,e.y,'#fff')}B.started=1}
 for(const b of B.bld)stepDefense(B,b,dt);
 for(const u of B.units)stepUnit(B,u,dt);
 B.units=B.units.filter(u=>u.hp>0);stepProj(B,dt);stepFx(B,dt);
 // конец боя
 const att=B.units.filter(u=>u.s==0&&u.fl!='l'&&u.hp>0).length,left=B.script?(B.script.length-B.sch):Object.values(B.army).reduce((a,b)=>a+b,0);
 if(B.pct>=100)endBattle(B,'full');else if(B.started&&B.clock>=BATTLE_TIME)endBattle(B,'time');else if(B.started&&att==0&&left<=0&&B.t>1)endBattle(B,'army');}
function endBattle(B,why){if(B.over)return;B.over=1;B.why=why;const sb=subBonus(),f=B.pct/100;
 B.gold=Math.floor((B.base.gold||0)*f*sb.loot);B.chek=Math.floor((B.base.chek||0)*f*sb.loot);
 const cu=B.base.cups||0;B.cups=B.stars==0?-Math.round(cu*.4):Math.round(cu*[0,.6,1,1.5][B.stars]*sb.cups);if(B.base.arena){B.gold*=2;B.chek*=2}}
