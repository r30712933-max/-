// economy.js — ресурсы, постройка/улучшение, добыча, очередь тренировки, лаборатория, достижения
const nowMs=()=>Date.now();
const thLevel=()=>{const r=S.bld.find(b=>b.t=='residence');return r?r.l:1};
const busy=b=>b.up>nowMs();
const placed=b=>!b.stored;
const active=b=>placed(b)&&!(b.cons&&busy(b));          // достроено и работает
const lvlOf=b=>b.l;
function capOf(k){let c=k=='gold'?resGold(thLevel()):resChek(thLevel());const st=k=='gold'?'gold_store':'chek_store';
 for(const b of S.bld)if(b.t==st&&active(b))c+=storeCap(b.l);return c}
function addRes(k,n){const c=capOf(k),b=S[k];S[k]=Math.max(0,Math.min(c,b+n));return S[k]-b}
function canPay(g,ch){return S.gold>=(g||0)&&S.chek>=(ch||0)}
function pay(g,ch){S.gold-=g||0;S.chek-=ch||0}
function playerLevel(){return 1+Math.floor(Math.sqrt(S.xp/45))}
function addXp(n){const a=playerLevel();S.xp+=n;if(playerLevel()>a)toast('Новый уровень игрока: '+playerLevel()+'!')}
const builders=()=>thLevel()>=4?3:2;
const busyBuilders=()=>S.bld.filter(b=>b.up>nowMs()&&placed(b)&&BD[b.t].bt>1).length;
function chekBonus(){const h=S.bld.find(b=>b.t=='chek_house'&&active(b));return h?1+.1*h.l:1}
function subBonus(){const h=S.bld.find(b=>b.t=='sub_center'&&active(b));return h?{cups:1+.15*h.l,loot:1+.06*h.l}:{cups:1,loot:1}}
// ---- сетка ----
function occGrid(ignoreId){const o=new Int32Array(GN*GN);for(const b of S.bld){if(!placed(b)||b.id===ignoreId)continue;const w=BD[b.t].w;for(let i=0;i<w;i++)for(let j=0;j<w;j++)o[(b.x+i)*GN+b.y+j]=b.id}return o}
function canPlaceAt(t,x,y,ignoreId,occ){const w=BD[t].w;if(x<PAD||y<PAD||x+w>GN-PAD||y+w>GN-PAD)return false;occ=occ||occGrid(ignoreId);
 for(let i=0;i<w;i++)for(let j=0;j<w;j++)if(occ[(x+i)*GN+y+j])return false;return true}
function countOf(t){return S.bld.filter(b=>b.t==t).length}
function freeSpot(t){const w=BD[t].w,occ=occGrid();const cx=GN/2;let best=null,bd=1e9;for(let x=PAD;x<=GN-PAD-w;x++)for(let y=PAD;y<=GN-PAD-w;y++){if(!canPlaceAt(t,x,y,0,occ))continue;const d=Math.hypot(x-cx+w/2,y-cx+w/2);if(d<bd){bd=d;best=[x,y]}}return best}
// ---- строительство ----
function reasonCantBuild(t){const th=thLevel();if(unlockTH(t)>th)return 'Нужна Резиденция ур. '+unlockTH(t);
 if(countOf(t)>=maxCount(t,th))return 'Достигнут лимит ('+maxCount(t,th)+')';
 if(S.gold<BD[t].cost)return 'Не хватает золота';
 if(BD[t].bt>1&&busyBuilders()>=builders())return 'Все строители заняты';return ''}
function placeBuilding(t,x,y,flip){const r=reasonCantBuild(t);if(r)return r;if(!canPlaceAt(t,x,y))return 'Место занято';
 pay(BD[t].cost);const b={id:S.nid++,t,x,y,l:1,flip:flip?1:0,up:0,upTo:0,cons:0,acc:{gold:0,chek:0},stored:0};
 if(BD[t].bt>1){b.cons=1;b.up=nowMs()+BD[t].bt*1000}S.bld.push(b);addXp(Math.max(2,BD[t].cost/40|0));SFX.build();saveGame();return ''}
function reasonCantUp(b){if(busy(b))return 'Уже строится';const n=b.l+1,th=thLevel();
 if(b.l>=maxLevel(b.t,th)){return b.t=='residence'?(b.l>=5?'Максимальный уровень':''):(maxLevel(b.t,th)>=maxLevel(b.t,5)?'Максимальный уровень':'Нужна Резиденция ур. '+(BD[b.t].ml.findIndex(m=>m>b.l)+1))}
 if(S.gold<upCost(b.t,n))return 'Не хватает золота';if(busyBuilders()>=builders())return 'Все строители заняты';return ''}
function startUpgrade(b){const r=reasonCantUp(b);if(r)return r;const n=b.l+1;pay(upCost(b.t,n));b.upTo=n;b.up=nowMs()+upTime(b.t,n)*1000;SFX.upgrade();saveGame();return ''}
function removeToStorage(b){if(b.t=='residence')return;collect(b,true);b.stored=1;b.x=-1;b.y=-1;saveGame()}
function finishTimers(){const t=nowMs();let any=0;
 for(const b of S.bld){if(b.up&&b.up<=t){if(b.cons){b.cons=0;b.acc={gold:0,chek:0}}else if(b.upTo){b.l=b.upTo;if(b.t=='residence')toast('Резиденция Мэла: уровень '+b.l+'! Открыты новые здания.')}
  b.up=0;b.upTo=0;any=1;addXp(b.l*6);if(window.onBuilt)onBuilt(b)}}
 if(S.lab&&S.lab.end<=t){S.ul[S.lab.u]=S.lab.l;toast(UC[S.lab.u][0]+' улучшен до ур. '+S.lab.l);S.lab=null;SFX.upgrade();any=1}return any}
// ---- добыча ----
function tickEconomy(dt){const hb=chekBonus();for(const b of S.bld){if(!active(b)||busy(b))continue;const p=prod(b.t,b.l,hb);if(!p)continue;for(const k in p){const cap=p[k]*COLCAP;b.acc[k]=Math.min(cap,(b.acc[k]||0)+p[k]*dt)}}}
function collectible(b){if(!active(b)||busy(b)||!prod(b.t,b.l))return 0;let s=0;for(const k in b.acc)s+=b.acc[k]>=1?b.acc[k]:0;return s}
function collect(b,silent){let got={};for(const k of['gold','chek']){const a=Math.floor(b.acc[k]||0);if(a<1)continue;const d=addRes(k,a);b.acc[k]-=d;if(d>0)got[k]=d}return got}
// ---- армия и очередь ----
function armyCap(){let c=25;for(const b of S.bld)if(b.t=='camp'&&active(b))c+=campCap(b.l);return c}
function armyUsed(){let s=0;for(const k in S.army)s+=S.army[k]*unitSpace(+k);return s}
function queueUsed(){return S.queue.reduce((a,q)=>a+unitSpace(q.u),0)}
const barracksList=()=>S.bld.filter(b=>b.t=='barracks'&&active(b)&&!busy(b));
const queueCap=()=>4+4*barracksList().length;
function reasonCantTrain(i){if(!barracksList().length)return 'Нужны казармы';if(unlockLvl(i)>thLevel())return 'Нужна Резиденция ур. '+unlockLvl(i);
 if(S.queue.length>=queueCap())return 'Очередь заполнена';if(armyUsed()+queueUsed()+unitSpace(i)>armyCap())return 'Нет места в армии';if(S.chek<trainCost(i))return 'Не хватает чекушек';return ''}
function enqueue(i){const r=reasonCantTrain(i);if(r)return r;pay(0,trainCost(i));S.queue.push({u:i,p:0});SFX.train();return ''}
function cancelQueue(idx){const q=S.queue[idx];if(!q)return;addRes('chek',trainCost(q.u));S.queue.splice(idx,1)}
function tickQueue(dt){const bl=barracksList();if(!bl.length||!S.queue.length)return;const spd=bl.reduce((a,b)=>a+1+.2*(b.l-1),0)/bl.length;
 const lines=Math.min(bl.length,S.queue.length);let done=0;
 for(let k=0;k<lines;k++){const q=S.queue[k-done];q.p+=dt*spd;if(q.p>=trainTime(q.u)){S.army[q.u]=(S.army[q.u]||0)+1;S.queue.splice(k-done,1);done++;SFX.ready()}}}
const unitLvl=i=>S.ul[i]||1;
// ---- лаборатория ----
const labB=()=>S.bld.find(b=>b.t=='lab'&&active(b)&&!busy(b));
function reasonCantResearch(i){const l=labB();if(!l)return 'Нужна лаборатория';if(S.lab)return 'Лаборатория занята';const n=unitLvl(i)+1;
 if(n>labMax(l.l))return 'Нужна лаборатория выше уровнем';if(n>5)return 'Максимум';if(unlockLvl(i)>thLevel())return 'Боец ещё закрыт';if(S.chek<labCost(i,n))return 'Не хватает чекушек';return ''}
function startResearch(i){const r=reasonCantResearch(i);if(r)return r;const n=unitLvl(i)+1;pay(0,labCost(i,n));S.lab={u:i,l:n,end:nowMs()+labTime(i,n)*1000};SFX.upgrade();return ''}
// ---- достижения ----
const ACH=[{id:'b5',n:'Прораб',d:'Построй 5 зданий',ok:()=>S.bld.length>=8,r:150},{id:'a1',n:'Первый поход',d:'Соверши нападение',ok:()=>S.stats.att>=1,r:150},
 {id:'w3',n:'Серия побед',d:'Выиграй 3 раза',ok:()=>S.stats.wins>=3,r:300},{id:'s3',n:'Звёздный час',d:'Получи 3 звезды в бою',ok:()=>S.stats.maxStars>=3,r:400},
 {id:'t2',n:'Новоселье',d:'Резиденция ур. 2',ok:()=>thLevel()>=2,r:300},{id:'t3',n:'Особняк',d:'Резиденция ур. 3',ok:()=>thLevel()>=3,r:700},
 {id:'t5',n:'Мемная крепость',d:'Резиденция ур. 5',ok:()=>thLevel()>=5,r:5000},{id:'c100',n:'Сотка',d:'Набери 100 кубков',ok:()=>S.cups>=100,r:500},
 {id:'lab',n:'Учёный',d:'Улучши бойца в лаборатории',ok:()=>Object.keys(S.ul).length>0,r:300},{id:'d1',n:'Крепкий щит',d:'Отрази учебный набег на базу',ok:()=>S.stats.defs>=1,r:300}];
function checkAch(){for(const a of ACH)if(!S.ach[a.id]&&a.ok()){S.ach[a.id]=1;addRes('gold',a.r);toast('Достижение: '+a.n+' (+'+a.r+' золота)');SFX.ready()}}
// ---- оффлайн ----
function applyOffline(){const dt=Math.min(12*3600,Math.max(0,(nowMs()-S.last)/1000));if(dt<2)return 0;tickEconomy(dt);tickQueue(dt);finishTimers();return dt}
