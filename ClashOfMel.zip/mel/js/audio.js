// audio.js — звук. Синтезатор (au/tone/noise/kick/snare) перенесён из ML Royale, набор эффектов — новый.
let VOL=.8,mute=false,AC,MG,RV;
function au(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)();const cp=AC.createDynamicsCompressor();cp.threshold.value=-16;cp.ratio.value=5;MG=AC.createGain();MG.gain.value=VOL;MG.connect(cp);cp.connect(AC.destination);const n=AC.sampleRate*1.3|0,b=AC.createBuffer(2,n,AC.sampleRate);for(let c=0;c<2;c++){const d=b.getChannelData(c);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2.6)}RV=AC.createConvolver();RV.buffer=b;const rg=AC.createGain();rg.gain.value=.28;RV.connect(rg);rg.connect(MG)}catch(e){}}if(AC&&AC.state=='suspended')AC.resume();return AC}
const mf=m=>440*Math.pow(2,(m-69)/12);
function tone(f,d,ty,v,sl,dl,wet){if(mute)return;const a=au();if(!a||a.state!='running')return;const t=a.currentTime+(dl||0),o=a.createOscillator(),g=a.createGain();o.type=ty||'square';o.frequency.setValueAtTime(f,t);if(sl&&sl!=1)o.frequency.exponentialRampToValueAtTime(Math.max(25,f*sl),t+d);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v||.08,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(MG);if(wet){const w=a.createGain();w.gain.value=wet;g.connect(w);w.connect(RV)}o.start(t);o.stop(t+d+.03)}
function noise(d,v,fq,ty,dl){if(mute)return;const a=au();if(!a||a.state!='running')return;const n=a.sampleRate*d|0,b=a.createBuffer(1,n,a.sampleRate),x=b.getChannelData(0);for(let i=0;i<n;i++)x[i]=(Math.random()*2-1)*Math.pow(1-i/n,1.5);const s=a.createBufferSource(),f=a.createBiquadFilter(),g=a.createGain();f.type=ty||'lowpass';f.frequency.value=fq;g.gain.value=v;s.buffer=b;s.connect(f);f.connect(g);g.connect(MG);s.start(a.currentTime+(dl||0))}
const kick=()=>{tone(160,.18,'sine',.4,.22)},snare=()=>{noise(.13,.17,1900,'bandpass');tone(190,.08,'triangle',.1,.6)},hat=o=>noise(o?.14:.04,.055,7500,'highpass');
const lastS={};
const SFX={
 click:()=>tone(720,.05,'triangle',.07,.8),
 build:()=>{tone(380,.14,'sine',.2,2.4,0,.2);tone(1200,.12,'triangle',.07,1,.07,.4);noise(.12,.06,2500,'highpass');tone(110,.3,'sine',.3,.4)},
 upgrade:()=>{[0,4,7,12].forEach((n,i)=>tone(mf(64+n),.25,'triangle',.09,1,i*.07,.3))},
 collect:()=>{tone(1320,.08,'square',.05,1);tone(1760,.12,'square',.05,1,.07)},
 train:()=>{tone(300,.1,'square',.05,1.6);noise(.06,.05,1800,'bandpass')},
 ready:()=>{tone(880,.1,'triangle',.1,1);tone(1320,.18,'triangle',.08,1,.1)},
 deploy:()=>{tone(520,.16,'square',.045,.25);noise(.12,.08,900,'bandpass')},
 shoot:()=>{tone(950,.1,'triangle',.07,.35);noise(.05,.05,3500,'highpass')},
 cannon:()=>{noise(.25,.25,700,'lowpass');tone(120,.2,'sine',.3,.4)},
 hit:()=>{noise(.07,.14,1200,'bandpass');tone(170,.09,'sine',.2,.4)},
 boom:()=>{noise(.9,.5,500,'lowpass');tone(95,.8,'sine',.5,.3);noise(.3,.12,3000,'highpass',.05);tone(60,.6,'sawtooth',.1,.5)},
 pop:()=>{tone(520,.16,'square',.045,.25);noise(.12,.08,900,'bandpass')},
 ban:()=>{tone(200,.25,'sawtooth',.1,.5);tone(100,.3,'square',.08,.5,.1)},
 error:()=>{tone(180,.18,'square',.07,.7)},
 win:()=>{[0,4,7,12,16].forEach((n,i)=>{tone(mf(60+n),.5,'square',.06,1,i*.12,.4);tone(mf(48+n),.5,'triangle',.09,1,i*.12)});kick()},
 lose:()=>{[0,-1,-3,-5].forEach((n,i)=>tone(mf(57+n),.55,'sawtooth',.05,.98,i*.25,.4))}};
let _t=0;function snd(k){if(mute)return;const t=performance.now();if(lastS[k]&&t-lastS[k]<70)return;lastS[k]=t;try{SFX[k]()}catch(e){}}
for(const k in SFX){const f=SFX[k];SFX[k]=function(){if(mute)return;try{f.apply(null,arguments)}catch(e){}}}
document.addEventListener('pointerdown',()=>{try{au()}catch(e){}});
function setVol(v){VOL=v;if(MG)MG.gain.value=v}
