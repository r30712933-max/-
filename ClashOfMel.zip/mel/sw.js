const C='mel-v1',F=["./", "index.html", "manifest.webmanifest", "css/style.css", "js/ai.js", "js/art.js", "js/audio.js", "js/buildings.js", "js/combat.js", "js/economy.js", "js/game.js", "js/save.js", "js/sprites.js", "js/ui.js", "js/units.js", "js/world.js", "assets/icon.png", "assets/icon-192.png", "assets/icon-512.png", "assets/cover.png"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
